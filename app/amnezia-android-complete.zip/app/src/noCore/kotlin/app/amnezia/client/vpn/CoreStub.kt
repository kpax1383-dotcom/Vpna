package app.amnezia.client.vpn

import android.net.VpnService

/** Compiled when app/libs/libbox.aar is absent: everything works except the tunnel itself. */
internal fun createCore(service: VpnService, perApp: PerApp, log: (String) -> Unit): VpnCore = object : VpnCore {
    override fun start(config: String) {
        throw IllegalStateException("The sing-box core (libbox.aar) is not in this build. Put app/libs/libbox.aar next to the app and rebuild (see README).")
    }
    override fun stop() {}
}
