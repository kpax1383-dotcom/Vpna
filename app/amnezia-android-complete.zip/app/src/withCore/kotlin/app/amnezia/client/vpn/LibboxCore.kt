package app.amnezia.client.vpn

// ============================================================================================================
// UNVERIFIED against your libbox.aar. This file was written from the documented sing-box (1.12) libbox API
// without being compiled. libbox's `PlatformInterface` changes between sing-box versions: if the build says
// "does not implement abstract member X" or "unresolved reference", the signatures in your AAR differ.
// Get the exact API with:
//     unzip -p app/libs/libbox.aar classes.jar > /tmp/classes.jar
//     javap -classpath /tmp/classes.jar io.nekohasekai.libbox.PlatformInterface io.nekohasekai.libbox.TunOptions \
//           io.nekohasekai.libbox.InterfaceUpdateListener io.nekohasekai.libbox.SetupOptions io.nekohasekai.libbox.Libbox
// and adjust the overrides below (the logic - protect(), openTun(), default-interface monitor - stays the same).
// ============================================================================================================

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import io.nekohasekai.libbox.BoxService
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.SetupOptions
import io.nekohasekai.libbox.TunOptions
import java.net.NetworkInterface

internal fun createCore(service: VpnService, perApp: PerApp, log: (String) -> Unit): VpnCore = LibboxCore(service, perApp, log)

private class LibboxCore(private val service: VpnService, private val perApp: PerApp, private val log: (String) -> Unit) : VpnCore {
    private var box: BoxService? = null

    override fun start(config: String) {
        val base = service.filesDir.absolutePath
        Libbox.setup(SetupOptions().also { it.basePath = base; it.workingPath = base; it.tempPath = service.cacheDir.absolutePath })
        val svc = Libbox.newService(config, Platform(service, perApp, log))
        svc.start()
        box = svc
    }

    override fun stop() {
        runCatching { box?.close() }
        box = null
    }
}

private class Platform(private val svc: VpnService, private val perApp: PerApp, private val log: (String) -> Unit) : PlatformInterface {
    private var callback: ConnectivityManager.NetworkCallback? = null
    private val cm get() = svc.getSystemService(ConnectivityManager::class.java)

    // Sockets the core opens to the proxy server must bypass the VPN itself.
    override fun usePlatformAutoDetectInterfaceControl() = true
    override fun autoDetectInterfaceControl(fd: Int) { svc.protect(fd) }

    override fun openTun(options: TunOptions): Int {
        if (VpnService.prepare(svc) != null) error("VPN permission is missing")
        val b = svc.Builder().setSession("Amnezia").setMtu(options.mtu)
        val v4 = options.inet4Address
        while (v4.hasNext()) { val a = v4.next(); b.addAddress(a.address(), a.prefix()) }
        val v6 = options.inet6Address
        while (v6.hasNext()) { val a = v6.next(); b.addAddress(a.address(), a.prefix()) }
        if (options.autoRoute) {
            b.addDnsServer(options.dnsServerAddress.value)
            b.addRoute("0.0.0.0", 0)
            b.addRoute("::", 0)
        }
        // Per-app proxy: Android's own allow/deny lists (an empty allow list would mean "all apps", so "include" needs at least one package).
        when {
            perApp.mode == "include" && perApp.packages.isNotEmpty() -> perApp.packages.forEach { runCatching { b.addAllowedApplication(it) } }
            perApp.mode == "exclude" -> perApp.packages.forEach { runCatching { b.addDisallowedApplication(it) } }
        }
        val pfd = b.establish() ?: error("Could not start the VPN (permission revoked?)")
        return pfd.detachFd()
    }

    // The default (non-VPN) network: the core needs its interface name to bind outgoing sockets.
    override fun usePlatformDefaultInterfaceMonitor() = true
    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN).build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = report(network, listener)
            override fun onLost(network: Network) { listener.updateDefaultInterface("", -1, false, false) }
        }
        callback = cb
        cm.registerNetworkCallback(req, cb)
    }
    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        callback?.let { runCatching { cm.unregisterNetworkCallback(it) } }
        callback = null
    }
    private fun report(network: Network, listener: InterfaceUpdateListener) {
        val name = cm.getLinkProperties(network)?.interfaceName ?: return
        val index = runCatching { NetworkInterface.getByName(name)?.index ?: 0 }.getOrDefault(0)
        listener.updateDefaultInterface(name, index, false, false)
    }

    override fun usePlatformInterfaceGetter() = false
    override fun getInterfaces(): NetworkInterfaceIterator = object : NetworkInterfaceIterator {
        override fun hasNext() = false
        override fun next() = error("no interfaces")
    }

    override fun useProcFS() = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
    override fun underNetworkExtension() = false
    override fun includeAllNetworks() = false
    override fun clearDNSCache() {}
    override fun writeLog(message: String?) { log(message ?: "") }
}
