package app.amnezia.client.data

import app.amnezia.client.config.ParsedServer
import app.amnezia.client.config.parseText
import java.io.IOException
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import javax.net.ssl.SSLException

class SubscriptionException(val code: String, message: String, val status: Int? = null) : Exception(message)

data class Usage(val upload: Long, val download: Long, val total: Long, val expire: Long)
data class SubMeta(val title: String?, val usage: Usage?, val intervalHours: Int?, val supportUrl: String?)
data class SubResult(val servers: List<ParsedServer>, val errors: List<String>, val meta: SubMeta)

/** Response with lower-cased header names. */
data class HttpResult(val status: Int, val headers: Map<String, String>, val body: String)

fun interface Http { fun get(url: String, headers: Map<String, String>): HttpResult }

/** The device identity Happ-compatible providers (Remnawave, 3x-ui, Marzban) read. Only x-hwid is mandatory. */
data class DeviceInfo(val os: String = "Android", val osVersion: String = "", val model: String = "", val locale: String = "en")

data class SubSettings(val userAgent: String = "Happ", val customUserAgent: String = "", val sendHwid: Boolean = true, val hwid: String = "", val device: DeviceInfo = DeviceInfo())

object UrlConnectionHttp : Http {
    override fun get(url: String, headers: Map<String, String>): HttpResult {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000; c.readTimeout = 20000; c.instanceFollowRedirects = true
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            val status = c.responseCode
            val stream = if (status in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            val h = HashMap<String, String>()
            for ((k, v) in c.headerFields) if (k != null && v.isNotEmpty()) h[k.lowercase()] = v.first()
            return HttpResult(status, h, body)
        } catch (e: IOException) {
            throw SubscriptionException("network", "Could not reach the subscription server: ${describeNetworkError(e)}")
        } finally { c.disconnect() }
    }
}

fun describeNetworkError(e: Throwable): String {
    val raw = listOfNotNull(e.javaClass.simpleName, e.message).joinToString(": ")
    val hint = when {
        e is UnknownHostException -> "DNS lookup failed — the domain does not resolve (check the link, your DNS or the internet connection)."
        e is SocketTimeoutException -> "The connection timed out — the host may be blocked by your network or provider."
        e is ConnectException -> "The server refused or could not accept the connection."
        e is SSLException -> "TLS/certificate error — check the phone's date and time."
        else -> null
    }
    return if (hint != null) "$hint ($raw)" else raw
}

/** Accepts https:// links and the deep links Happ-style apps use: happ://add/<url>. */
fun normalizeSubscriptionUrl(input: String): String {
    val s = input.trim()
    if (Regex("^happ://crypt", RegexOption.IGNORE_CASE).containsMatchIn(s)) {
        throw SubscriptionException("encrypted", "This link is encrypted by Happ. Ask your provider for the regular https:// subscription link.")
    }
    Regex("^(?:happ|amnezia)://add/(.+)$", RegexOption.IGNORE_CASE).find(s)?.let {
        val inner = it.groupValues[1]
        return normalizeSubscriptionUrl(if (Regex("^https?%3A", RegexOption.IGNORE_CASE).containsMatchIn(inner)) java.net.URLDecoder.decode(inner, "UTF-8") else inner)
    }
    if (!Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(s)) throw SubscriptionException("bad_url", "Expected an https:// subscription link")
    try { URL(s) } catch (_: Exception) { throw SubscriptionException("bad_url", "Malformed subscription URL") }
    return s
}

fun parseUserInfo(h: String?): Usage? {
    if (h == null) return null
    val out = HashMap<String, Long>()
    for (part in h.split(';')) {
        val k = part.substringBefore('=', "").trim().lowercase(); val v = part.substringAfter('=', "").trim().toDoubleOrNull() ?: continue
        if (k.isNotEmpty()) out[k] = v.toLong()
    }
    if (out["total"] == null && out["download"] == null && out["upload"] == null) return null
    return Usage(out["upload"] ?: 0, out["download"] ?: 0, out["total"] ?: 0, out["expire"] ?: 0)
}

fun decodeTitle(h: String?): String? {
    if (h.isNullOrBlank()) return null
    val v = h.trim()
    if (v.startsWith("base64:", ignoreCase = true)) return try { String(java.util.Base64.getDecoder().decode(v.substring(7)), Charsets.UTF_8) } catch (_: Exception) { null }
    return try { java.net.URLDecoder.decode(v.replace("+", "%2B"), "UTF-8") } catch (_: Exception) { v }
}

/** HTTP header values must be plain ASCII here; a localised device name must never make the request fail. */
fun asciiHeader(v: String, fallback: String): String {
    val c = v.filter { it.code in 0x20..0x7E }.trim()
    return if (c.any { it.isLetterOrDigit() }) c else fallback
}

fun userAgentFor(s: SubSettings): String = when (s.userAgent) {
    "Happ" -> "Happ/2.0.0"
    "v2rayN" -> "v2rayN/7.0.0"
    "custom" -> s.customUserAgent.ifEmpty { "sing-box" }
    else -> "sing-box"
}

fun buildHeaders(s: SubSettings): Map<String, String> {
    val h = LinkedHashMap<String, String>()
    h["User-Agent"] = userAgentFor(s); h["Accept"] = "*/*"
    if (s.sendHwid && s.hwid.isNotEmpty()) {
        h["x-hwid"] = s.hwid
        h["x-device-os"] = s.device.os
        h["x-ver-os"] = asciiHeader(s.device.osVersion, "0")
        h["x-device-model"] = asciiHeader(s.device.model, "Android")
        h["x-device-locale"] = asciiHeader(s.device.locale, "en")
    }
    return h
}

class ProviderSignals(val announce: String?, val limitReached: Boolean, val hwidNotSupported: Boolean)

fun providerSignals(h: Map<String, String>): ProviderSignals {
    fun on(k: String) = h[k]?.trim()?.lowercase() == "true"
    return ProviderSignals(decodeTitle(h["announce"]), on("x-hwid-max-devices-reached") || on("x-hwid-limit"), on("x-hwid-not-supported"))
}

private fun describeHttpFailure(res: HttpResult, hwid: String?): String {
    val sig = providerSignals(res.headers)
    val said = if (sig.announce != null) " Provider message: \"${sig.announce}\"." else ""
    val id = if (hwid != null) " This device's HWID: $hwid." else ""
    if (sig.limitReached) return "Device limit reached (HWID).$said Remove an old device in the provider's bot/cabinet, then refresh.$id"
    if (sig.hwidNotSupported) return "The provider requires a device ID (HWID), but none was accepted. Enable \"Send HWID\" in settings.$said"
    if (res.status == 401 || res.status == 403) {
        return "$said The provider may bind subscriptions to a device (HWID) or a specific app, or the device limit is reached (remove an old device in the provider's bot/cabinet). Try another User-Agent or enable HWID in settings.$id".trim()
    }
    return said.trim()
}

/** Downloads and parses a subscription. Blocking: call it off the main thread. */
fun fetchSubscription(rawUrl: String, settings: SubSettings, http: Http = UrlConnectionHttp): SubResult {
    val url = normalizeSubscriptionUrl(rawUrl)
    var res = http.get(url, buildHeaders(settings))
    var hwidSent = settings.sendHwid && settings.hwid.isNotEmpty()
    var hwid = settings.hwid
    // Providers answer 401/403 to unknown clients, and 404 to clients without HWID when a device limit is on.
    // Retry once the way Happ does: Happ User-Agent plus the same stable HWID (never a fresh one: that would burn a device slot per attempt).
    val needsHwid = res.status == 401 || res.status == 403 || (res.status == 404 && providerSignals(res.headers).hwidNotSupported)
    if (needsHwid && !(settings.userAgent == "Happ" && hwidSent)) {
        hwid = settings.hwid.ifEmpty { newHwid() }
        res = http.get(url, buildHeaders(settings.copy(userAgent = "Happ", sendHwid = true, hwid = hwid)))
        hwidSent = true
    }
    if (res.status !in 200..299) {
        val detail = describeHttpFailure(res, if (hwidSent) hwid else null)
        throw SubscriptionException("http", "Server answered ${res.status}.${if (detail.isNotEmpty()) " $detail" else ""}", res.status)
    }
    val parsed = parseText(res.body)
    val title = decodeTitle(res.headers["profile-title"])
    val meta = SubMeta(title, parseUserInfo(res.headers["subscription-userinfo"]), res.headers["profile-update-interval"]?.toDoubleOrNull()?.toInt()?.takeIf { it > 0 }, res.headers["support-url"])
    if (parsed.servers.isEmpty()) throw SubscriptionException("empty", parsed.errors.firstOrNull() ?: "The subscription contains no supported servers")
    return SubResult(parsed.servers, parsed.errors, meta)
}

fun newHwid(): String {
    val b = ByteArray(8); java.security.SecureRandom().nextBytes(b)
    return b.joinToString("") { "%02x".format(it) }
}
