package app.amnezia.client.vpn

import android.net.VpnService

/** The tunnel engine. The real one wraps sing-box's libbox (src/withCore); without libbox.aar a stub is compiled (src/noCore). */
interface VpnCore {
    /** Starts the engine with a full sing-box JSON config. Throws with a readable message when it cannot. */
    fun start(config: String)
    fun stop()
}

/** Which apps go through the tunnel: mode "off" = all, "include" = only [packages], "exclude" = all except [packages]. */
data class PerApp(val mode: String = "off", val packages: Set<String> = emptySet())

/** Implemented once per source set (noCore / withCore). */
object CoreFactory {
    fun create(service: VpnService, perApp: PerApp, log: (String) -> Unit): VpnCore = createCore(service, perApp, log)
}
