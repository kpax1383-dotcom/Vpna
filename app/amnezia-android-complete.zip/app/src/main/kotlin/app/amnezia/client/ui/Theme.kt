package app.amnezia.client.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Palette {
    val Bg = Color(0xFF07090F)
    val Bg2 = Color(0xFF0E1220)
    val Accent = Color(0xFF0A84FF)
    val Accent2 = Color(0xFF5AC8FA)
    val Danger = Color(0xFFFF453A)
    val Card = Color(0x0FFFFFFF)          // white at 6 %
    val CardBorder = Color(0x1AFFFFFF)    // white at 10 %
    val Text = Color(0xFFF2F4FA)
    val Muted = Color(0xFF8A90A6)
}

@Composable
fun AmneziaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.Accent, secondary = Palette.Accent2, background = Palette.Bg, surface = Palette.Bg2,
            onBackground = Palette.Text, onSurface = Palette.Text, onPrimary = Color.White, error = Palette.Danger,
        ),
        content = content,
    )
}
