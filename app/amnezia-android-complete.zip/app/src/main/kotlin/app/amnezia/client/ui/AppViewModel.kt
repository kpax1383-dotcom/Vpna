package app.amnezia.client.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.amnezia.client.config.isServerLink
import app.amnezia.client.config.parseText
import app.amnezia.client.data.Repository
import app.amnezia.client.data.Sub
import app.amnezia.client.data.SubscriptionException
import app.amnezia.client.data.fetchSubscription
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import android.content.Intent
import app.amnezia.client.data.pingAll
import app.amnezia.client.vpn.Phase
import app.amnezia.client.vpn.VpnState
import kotlinx.coroutines.launch

/** A message for the UI: either a plain text (errors come from the core in English) or a resource with a number. */
sealed interface Msg {
    data class Text(val text: String) : Msg
    data class Added(val n: Int) : Msg
    data class Refreshed(val n: Int) : Msg
    data object PingBlocked : Msg
    data object FileFailed : Msg
}

data class AppInfo(val label: String, val pkg: String)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val repo = Repository.get(app)
    val state = repo.state
    val busy = MutableStateFlow(false)
    val message = MutableStateFlow<Msg?>(null)
    /** server id -> ms; a null value means "no answer"; a missing key means "not measured". */
    val pings = MutableStateFlow<Map<String, Int?>>(emptyMap())
    val pinging = MutableStateFlow(false)
    val apps = MutableStateFlow<List<AppInfo>?>(null)

    init {
        // Auto-refresh subscriptions that are older than their update interval (default: 24 h).
        val now = System.currentTimeMillis()
        repo.state.value.subs.filter { now - it.updatedAt > (it.intervalHours ?: 24) * 3_600_000L }.forEach { refresh(it, silent = true) }
    }

    private fun looksLikeSubscription(t: String) = !isServerLink(t) && Regex("^(https?|happ|amnezia)://", RegexOption.IGNORE_CASE).containsMatchIn(t) && !t.contains('\n')

    fun add(raw: String, filename: String? = null) {
        val text = raw.trim()
        if (text.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            busy.value = true
            try {
                if (looksLikeSubscription(text)) {
                    val url = app.amnezia.client.data.normalizeSubscriptionUrl(text)
                    try {
                        val r = fetchSubscription(url, repo.state.value.settings.sub())
                        repo.saveSubscription(url, r)
                        message.value = Msg.Added(r.servers.size)
                    } catch (e: SubscriptionException) {
                        message.value = Msg.Text(e.message ?: "Error")
                    }
                } else {
                    val r = parseText(text, filename)
                    if (r.servers.isEmpty()) message.value = Msg.Text(r.errors.firstOrNull() ?: "No servers found")
                    else message.value = Msg.Added(repo.addServers(r.servers))
                }
            } catch (e: SubscriptionException) {
                message.value = Msg.Text(e.message ?: "Error")
            } finally { busy.value = false }
        }
    }

    fun measurePings() {
        val ph = VpnState.status.value.phase
        if (ph == Phase.On || ph == Phase.Connecting) { message.value = Msg.PingBlocked; return }
        if (pinging.value) return
        viewModelScope.launch {
            pinging.value = true; pings.value = emptyMap()
            try { pingAll(repo.state.value.servers) { id, ms -> pings.update { it + (id to ms) } } } finally { pinging.value = false }
        }
    }

    /** Launcher apps for the per-app picker (loaded once). */
    fun loadApps() {
        if (apps.value != null) return
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>(); val pm = ctx.packageManager
            val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            apps.value = pm.queryIntentActivities(launcher, 0).map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                .filter { it.pkg != ctx.packageName }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
        }
    }

    fun refresh(sub: Sub, silent: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            busy.value = true
            try {
                val r = fetchSubscription(sub.url, repo.state.value.settings.sub())
                repo.saveSubscription(sub.url, r)
                if (!silent) message.value = Msg.Refreshed(r.servers.size)
            } catch (e: SubscriptionException) {
                repo.markSubError(sub.url, e.message ?: "Error")
                if (!silent) message.value = Msg.Text(e.message ?: "Error")
            } finally { busy.value = false }
        }
    }
}
