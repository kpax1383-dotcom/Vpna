package app.amnezia.client.config

import org.json.JSONArray
import org.json.JSONObject
import org.yaml.snakeyaml.Yaml

// Clash / Clash.Meta YAML, Xray/V2Ray JSON and WireGuard .conf importers (ports of clash.ts, xray.ts, wireguard.ts, common.ts).

internal typealias Obj = Map<String, Any?>

internal fun Any?.asMap(): Obj? = (this as? Map<*, *>)?.entries?.associate { it.key.toString() to it.value }
internal fun Any?.asList(): List<Any?>? = this as? List<*>
internal fun Any?.asStr(): String? = when (this) {
    null -> null
    is String -> this.takeIf { it.isNotEmpty() }
    is Double -> if (this % 1.0 == 0.0) this.toLong().toString() else this.toString()
    else -> this.toString()
}
internal fun Any?.asStrList(): List<String>? = when (this) {
    is List<*> -> this.mapNotNull { it.asStr() }.ifEmpty { null }
    is String -> if (this.isEmpty()) null else this.split(',').map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { null }
    else -> null
}
internal fun Any?.asPort(def: Int): Int {
    val n = when (this) { is Number -> this.toInt(); is String -> this.trim().toIntOrNull(); else -> null }
    return if (n != null && n in 1..65535) n else def
}
private fun Any?.asInt(def: Int): Int = (this as? Number)?.toInt() ?: this.asStr()?.toIntOrNull() ?: def

internal fun jsonToKotlin(x: Any?): Any? = when (x) {
    is JSONObject -> x.keys().asSequence().associateWith { jsonToKotlin(x.get(it)) }
    is JSONArray -> (0 until x.length()).map { jsonToKotlin(x.get(it)) }
    JSONObject.NULL -> null
    else -> x
}

internal class RealityIn(val publicKey: String?, val shortId: String?)
internal class TlsIn(
    val enabled: Boolean, val serverName: String? = null, val insecure: Boolean = false,
    val alpn: List<String>? = null, val fingerprint: String? = null, val reality: RealityIn? = null,
)
internal class TransportIn(val network: String? = null, val path: String? = null, val host: List<String>? = null, val serviceName: String? = null, val httpHeader: Boolean = false)

internal fun tlsObj(i: TlsIn?, host: String): JSONObject? {
    if (i == null || !i.enabled) return null
    val tls = obj("enabled" to true, "server_name" to (i.serverName ?: host), "insecure" to if (i.insecure) true else null, "alpn" to i.alpn)
    val r = i.reality
    if (r != null) {
        if (r.publicKey == null) throw ConfigError("bad_config", "Reality is missing the public key")
        tls.put("reality", obj("enabled" to true, "public_key" to r.publicKey, "short_id" to r.shortId))
        tls.put("utls", obj("enabled" to true, "fingerprint" to (i.fingerprint ?: "chrome")))
    } else if (i.fingerprint != null) {
        tls.put("utls", obj("enabled" to true, "fingerprint" to i.fingerprint))
    }
    return tls
}

internal fun transportObj(i: TransportIn): Pair<JSONObject?, String> {
    val net = (i.network ?: "tcp").lowercase()
    val host = i.host
    return when (net) {
        "tcp", "raw", "" -> {
            if (i.httpHeader) throw ConfigError("unsupported", "TCP with HTTP header obfuscation is not supported")
            Pair(null, "TCP")
        }
        "ws", "websocket" -> Pair(obj("type" to "ws", "path" to i.path, "headers" to host?.firstOrNull()?.let { obj("Host" to it) }), "WS")
        "grpc" -> Pair(obj("type" to "grpc", "service_name" to (i.serviceName ?: i.path)), "gRPC")
        "httpupgrade" -> Pair(obj("type" to "httpupgrade", "path" to i.path, "host" to host?.firstOrNull()), "HTTPUpgrade")
        "h2", "http" -> Pair(obj("type" to "http", "path" to i.path, "host" to host), "HTTP")
        "xhttp", "splithttp" -> throw ConfigError("unsupported", "XHTTP transport is not supported by the sing-box core")
        "kcp", "mkcp", "quic", "ds", "domainsocket" -> throw ConfigError("unsupported", "Transport \"$net\" is not supported by the sing-box core")
        else -> throw ConfigError("unsupported", "Unsupported transport: $net")
    }
}

private fun withTlsLabel(label: String, tls: JSONObject?): String = if (tls == null) label else if (tls.has("reality")) "$label Reality" else "$label TLS"
private fun mk(name: String, protocol: String, transport: String, host: String, port: Int, ob: JSONObject, kind: String = "outbound") =
    ParsedServer(name, protocol, transport, host, port, ob, kind)

// ----------------------------------------------------------------------------------------------- Clash

fun isClashYaml(text: String): Boolean {
    val m = RegexOption.MULTILINE
    return Regex("^\\s*(proxies|proxy-groups|proxy-providers|mixed-port|port|socks-port|allow-lan|mode):", m).containsMatchIn(text) &&
        Regex("^\\s*proxies\\s*:", m).containsMatchIn(text)
}

private fun mbps(v: Any?): Int? = v.asStr()?.takeWhile { it.isDigit() }?.toIntOrNull()?.takeIf { it > 0 }
private fun cidr(a: Any?, bits: Int): String? = a.asStr()?.let { if (it.contains('/')) it else "$it/$bits" }

private fun clashTls(p: Obj, force: Boolean): JSONObject? {
    val reality = p["reality-opts"].asMap()
    val i = TlsIn(
        enabled = force || p["tls"] == true || reality != null,
        serverName = p["servername"].asStr() ?: p["sni"].asStr(),
        insecure = p["skip-cert-verify"] == true,
        alpn = p["alpn"].asStrList(),
        fingerprint = p["client-fingerprint"].asStr() ?: p["fingerprint"].asStr(),
        reality = reality?.let { RealityIn(it["public-key"].asStr(), it["short-id"].asStr()) },
    )
    return tlsObj(i, p["server"].asStr() ?: "")
}

private fun clashTransport(p: Obj): Pair<JSONObject?, String> {
    val network = p["network"].asStr() ?: "tcp"
    val ws = (p["ws-opts"] ?: p["ws-opt"]).asMap()
    val grpc = p["grpc-opts"].asMap(); val h2 = p["h2-opts"].asMap(); val http = p["http-opts"]
    val headers = ws?.get("headers").asMap() ?: emptyMap()
    val hostHdr = (headers["Host"] ?: headers["host"]).asStr()
    val hostList = hostHdr?.let { listOf(it) }
    return when {
        network == "ws" && ws?.get("v2ray-http-upgrade") == true -> transportObj(TransportIn("httpupgrade", ws["path"].asStr(), hostList))
        network == "ws" -> transportObj(TransportIn("ws", ws?.get("path").asStr(), hostList))
        network == "grpc" -> transportObj(TransportIn("grpc", serviceName = grpc?.get("grpc-service-name").asStr()))
        network == "h2" -> { val hp = h2?.get("path"); transportObj(TransportIn("h2", (if (hp is List<*>) hp.firstOrNull() else hp).asStr(), h2?.get("host").asStrList())) }
        network == "http" || (network == "tcp" && http != null) -> transportObj(TransportIn("tcp", httpHeader = true))
        else -> transportObj(TransportIn(network))
    }
}

private fun clashConvert(p: Obj): ParsedServer {
    val type = (p["type"].asStr() ?: "").lowercase()
    val host = p["server"].asStr(); val prt = p["port"].asPort(0)
    val name = p["name"].asStr() ?: "$host:$prt"
    if (host == null || prt == 0) throw ConfigError("bad_config", "proxy without server or port")
    return when (type) {
        "vless" -> {
            val uuid = p["uuid"].asStr() ?: throw ConfigError("bad_config", "vless without uuid")
            val tls = clashTls(p, false); val (transport, label) = clashTransport(p)
            mk(name, "vless", withTlsLabel(label, tls), host, prt, obj("type" to "vless", "server" to host, "server_port" to prt, "uuid" to uuid, "flow" to p["flow"].asStr(),
                "packet_encoding" to (p["packet-encoding"].asStr() ?: "xudp"), "tls" to tls, "transport" to transport))
        }
        "vmess" -> {
            val uuid = p["uuid"].asStr() ?: throw ConfigError("bad_config", "vmess without uuid")
            val tls = clashTls(p, false); val (transport, label) = clashTransport(p)
            mk(name, "vmess", withTlsLabel(label, tls), host, prt, obj("type" to "vmess", "server" to host, "server_port" to prt, "uuid" to uuid,
                "security" to (p["cipher"].asStr() ?: "auto"), "alter_id" to p["alterId"].asInt(0), "tls" to tls, "transport" to transport))
        }
        "trojan" -> {
            val pw = p["password"].asStr() ?: throw ConfigError("bad_config", "trojan without password")
            val tls = clashTls(p, true); val (transport, label) = clashTransport(p)
            mk(name, "trojan", withTlsLabel(label, tls), host, prt, obj("type" to "trojan", "server" to host, "server_port" to prt, "password" to pw, "tls" to tls, "transport" to transport))
        }
        "ss" -> {
            val cipher = p["cipher"].asStr(); if (cipher == null || !p.containsKey("password")) throw ConfigError("bad_config", "ss without cipher/password")
            val plugin = p["plugin"].asStr(); val po = p["plugin-opts"].asMap() ?: emptyMap()
            var pluginName: String? = null; var pluginOpts: String? = null
            if (plugin == "obfs") {
                pluginName = "obfs-local"
                pluginOpts = listOfNotNull(po["mode"].asStr()?.let { "obfs=$it" }, po["host"].asStr()?.let { "obfs-host=$it" }).joinToString(";")
            } else if (plugin == "v2ray-plugin") {
                pluginName = "v2ray-plugin"
                pluginOpts = listOfNotNull("mode=${po["mode"].asStr() ?: "websocket"}", if (po["tls"] == true) "tls" else null,
                    po["host"].asStr()?.let { "host=$it" }, po["path"].asStr()?.let { "path=$it" }, if (po["mux"] == true) "mux=1" else null).joinToString(";")
            } else if (plugin != null) throw ConfigError("unsupported", "Shadowsocks plugin \"$plugin\" is not supported")
            mk(name, "shadowsocks", if (pluginName != null) "SS $pluginName" else "Shadowsocks", host, prt,
                obj("type" to "shadowsocks", "server" to host, "server_port" to prt, "method" to cipher, "password" to p["password"].asStr(), "plugin" to pluginName, "plugin_opts" to pluginOpts))
        }
        "hysteria2", "hy2" -> {
            val pw = p["password"].asStr() ?: throw ConfigError("bad_config", "hysteria2 without password")
            val ports = p["ports"].asStr(); val obfs = p["obfs"].asStr()
            mk(name, "hysteria2", if (obfs != null) "Hysteria2 Obfs" else "Hysteria2", host, prt, obj(
                "type" to "hysteria2", "server" to host, "server_port" to prt, "server_ports" to ports?.split(',')?.map { it.trim().replace('-', ':') },
                "password" to pw, "up_mbps" to mbps(p["up"]), "down_mbps" to mbps(p["down"]),
                "obfs" to obfs?.let { obj("type" to it, "password" to p["obfs-password"].asStr()) },
                "tls" to obj("enabled" to true, "server_name" to (p["sni"].asStr() ?: host), "insecure" to if (p["skip-cert-verify"] == true) true else null, "alpn" to (p["alpn"].asStrList() ?: listOf("h3"))),
            ))
        }
        "socks5", "http" -> {
            val tls = clashTls(p, false); val socks = type == "socks5"
            mk(name, if (socks) "socks" else "http", if (socks) "SOCKS5" else "HTTP Proxy", host, prt, obj(
                "type" to if (socks) "socks" else "http", "server" to host, "server_port" to prt, "version" to if (socks) "5" else null,
                "username" to p["username"].asStr(), "password" to p["password"].asStr(), "tls" to tls))
        }
        "wireguard" -> {
            val priv = p["private-key"].asStr(); val pub = p["public-key"].asStr()
            if (priv == null || pub == null) throw ConfigError("bad_config", "wireguard without keys")
            val reserved = p["reserved"].asList()?.takeIf { it.size == 3 }?.map { it.asInt(0) }
            val peer = obj("address" to host, "port" to prt, "public_key" to pub, "pre_shared_key" to p["pre-shared-key"].asStr(),
                "allowed_ips" to (p["allowed-ips"].asStrList() ?: listOf("0.0.0.0/0", "::/0")), "reserved" to reserved)
            mk(name, "wireguard", "WireGuard", host, prt, obj("type" to "wireguard", "address" to listOfNotNull(cidr(p["ip"], 32), cidr(p["ipv6"], 128)),
                "private_key" to priv, "mtu" to p["mtu"].asStr()?.toIntOrNull(), "peers" to JSONArray().put(peer)), "endpoint")
        }
        else -> throw ConfigError("unsupported", "proxy type \"${type.ifEmpty { "?" }}\" is not supported")
    }
}

/** Clash / Clash.Meta / Mihomo YAML: converts the `proxies:` list into sing-box outbounds. */
fun parseClash(text: String): ParseResult {
    val doc: Any? = try { Yaml().load<Any?>(text) } catch (e: Exception) { return ParseResult(emptyList(), listOf("Invalid YAML: ${e.message?.lineSequence()?.firstOrNull() ?: ""}")) }
    val proxies = doc.asMap()?.get("proxies").asList()
    if (proxies.isNullOrEmpty()) return ParseResult(emptyList(), listOf("No proxies in the Clash config"))
    val servers = ArrayList<ParsedServer>(); val errors = ArrayList<String>()
    for (raw in proxies) {
        val p = raw.asMap() ?: continue
        try { servers.add(clashConvert(p)) } catch (e: ConfigError) { errors.add("${(p["name"].asStr() ?: p["server"].asStr() ?: "?").take(30)}: ${e.message}") }
    }
    return ParseResult(servers, errors)
}

// ------------------------------------------------------------------------------------------------ Xray

private val XRAY_PROXY = setOf("vless", "vmess", "trojan", "shadowsocks", "socks", "http", "wireguard", "hysteria")

/** True when the JSON looks like Xray/V2Ray: outbounds carry `protocol`, sing-box uses `type`. [json] is already converted by [jsonToKotlin]. */
fun isXrayJson(json: Any?): Boolean {
    val cfgs: List<Any?> = if (json is List<*>) json else listOf(json)
    return cfgs.any { c ->
        val o = c.asMap()
        (o?.get("protocol") as? String)?.let { it in XRAY_PROXY } == true || o?.get("outbounds").asList()?.any { x -> x.asMap()?.get("protocol") is String } == true
    }
}

private class Stream(val tls: JSONObject?, val transport: JSONObject?, val label: String)

private fun streamOf(ss: Obj?, host: String): Stream {
    if (ss == null) return Stream(null, null, "TCP")
    if (ss["sockopt"].asMap()?.get("dialerProxy") != null) throw ConfigError("unsupported", "proxy chaining (dialerProxy) is not supported")
    val network = ss["network"].asStr() ?: "tcp"
    val security = ss["security"].asStr() ?: "none"
    val t = ss["tlsSettings"].asMap() ?: emptyMap(); val r = ss["realitySettings"].asMap() ?: emptyMap()
    val tlsIn = if (security == "reality") TlsIn(true, r["serverName"].asStr(), fingerprint = r["fingerprint"].asStr(), reality = RealityIn(r["publicKey"].asStr(), r["shortId"].asStr()))
    else TlsIn(security == "tls", t["serverName"].asStr(), t["allowInsecure"] == true, t["alpn"].asStrList(), t["fingerprint"].asStr())
    val tls = tlsObj(tlsIn, host)
    val ws = ss["wsSettings"].asMap() ?: emptyMap(); val hu = ss["httpupgradeSettings"].asMap() ?: emptyMap()
    val grpc = ss["grpcSettings"].asMap() ?: emptyMap(); val h2 = (ss["httpSettings"] ?: ss["h2Settings"]).asMap() ?: emptyMap()
    val tcp = (ss["tcpSettings"] ?: ss["rawSettings"]).asMap() ?: emptyMap()
    val tr = when (network) {
        "ws" -> transportObj(TransportIn(network, ws["path"].asStr(), (ws["host"].asStr() ?: ws["headers"].asMap()?.get("Host").asStr())?.let { listOf(it) }))
        "httpupgrade" -> transportObj(TransportIn(network, hu["path"].asStr(), hu["host"].asStr()?.let { listOf(it) }))
        "grpc" -> transportObj(TransportIn(network, serviceName = grpc["serviceName"].asStr()))
        "h2", "http" -> transportObj(TransportIn(network, h2["path"].asStr(), h2["host"].asStrList()))
        else -> transportObj(TransportIn(network, httpHeader = tcp["header"].asMap()?.get("type") == "http"))
    }
    return Stream(tls, tr.first, withTlsLabel(tr.second, tls))
}

private fun xrayConvert(o: Obj, name: String): ParsedServer {
    val protocol = o["protocol"].asStr() ?: ""
    val s = o["settings"].asMap() ?: emptyMap()
    val vnext = s["vnext"].asList()?.firstOrNull().asMap()
    val user = vnext?.get("users").asList()?.firstOrNull().asMap() ?: emptyMap()
    val srv = s["servers"].asList()?.firstOrNull().asMap() ?: emptyMap()
    val host = vnext?.get("address").asStr() ?: srv["address"].asStr() ?: s["address"].asStr()
    val prt = (vnext?.get("port") ?: srv["port"] ?: s["port"]).asPort(0)
    if (protocol != "wireguard" && (host == null || prt == 0)) throw ConfigError("bad_config", "outbound without address or port")
    val stream = if (protocol == "wireguard") Stream(null, null, "WireGuard") else streamOf(o["streamSettings"].asMap(), host!!)
    val label = stream.label; val tls = stream.tls; val transport = stream.transport
    return when (protocol) {
        "vless" -> {
            val id = user["id"].asStr() ?: s["id"].asStr() ?: throw ConfigError("bad_config", "vless without id")
            mk(name, "vless", label, host!!, prt, obj("type" to "vless", "server" to host, "server_port" to prt, "uuid" to id, "flow" to (user["flow"].asStr() ?: s["flow"].asStr()), "packet_encoding" to "xudp", "tls" to tls, "transport" to transport))
        }
        "vmess" -> {
            val id = user["id"].asStr() ?: s["id"].asStr() ?: throw ConfigError("bad_config", "vmess without id")
            mk(name, "vmess", label, host!!, prt, obj("type" to "vmess", "server" to host, "server_port" to prt, "uuid" to id,
                "security" to (user["security"].asStr() ?: s["security"].asStr() ?: "auto"), "alter_id" to user["alterId"].asInt(0), "tls" to tls, "transport" to transport))
        }
        "trojan" -> {
            val pw = srv["password"].asStr() ?: s["password"].asStr() ?: throw ConfigError("bad_config", "trojan without password")
            mk(name, "trojan", label, host!!, prt, obj("type" to "trojan", "server" to host, "server_port" to prt, "password" to pw, "tls" to tls, "transport" to transport))
        }
        "shadowsocks" -> {
            val method = srv["method"].asStr() ?: s["method"].asStr(); val pw = srv["password"].asStr() ?: s["password"].asStr()
            if (method == null || pw == null) throw ConfigError("bad_config", "shadowsocks without method/password")
            mk(name, "shadowsocks", "Shadowsocks", host!!, prt, obj("type" to "shadowsocks", "server" to host, "server_port" to prt, "method" to method, "password" to pw))
        }
        "socks", "http" -> {
            val u = srv["users"].asList()?.firstOrNull().asMap() ?: emptyMap(); val socks = protocol == "socks"
            mk(name, if (socks) "socks" else "http", if (socks) "SOCKS5" else "HTTP Proxy", host!!, prt, obj("type" to protocol, "server" to host, "server_port" to prt,
                "version" to if (socks) "5" else null, "username" to u["user"].asStr(), "password" to u["pass"].asStr(), "tls" to tls))
        }
        "wireguard" -> {
            val peer = s["peers"].asList()?.firstOrNull().asMap() ?: emptyMap()
            val ep = peer["endpoint"].asStr(); val key = s["secretKey"].asStr(); val pub = peer["publicKey"].asStr()
            if (ep == null || key == null || pub == null) throw ConfigError("bad_config", "wireguard without endpoint/keys")
            val c = ep.lastIndexOf(':'); if (c < 0) throw ConfigError("bad_config", "wireguard endpoint needs host:port")
            val eh = ep.substring(0, c).removeSurrounding("[", "]"); val epPort = ep.substring(c + 1).asPort(51820)
            val reserved = s["reserved"].asList()?.takeIf { it.size == 3 }?.map { it.asInt(0) }
            val addr = s["address"].asStrList()?.map { if (it.contains('/')) it else "$it/${if (it.contains(':')) 128 else 32}" }
            mk(name, "wireguard", "WireGuard", eh, epPort, obj("type" to "wireguard", "address" to addr, "private_key" to key, "mtu" to s["mtu"].asStr()?.toIntOrNull(),
                "peers" to JSONArray().put(obj("address" to eh, "port" to epPort, "public_key" to pub, "pre_shared_key" to peer["preSharedKey"].asStr(),
                    "allowed_ips" to (peer["allowedIPs"].asStrList() ?: listOf("0.0.0.0/0", "::/0")), "reserved" to reserved))), "endpoint")
        }
        else -> throw ConfigError("unsupported", "protocol \"$protocol\" is not supported")
    }
}

/** Xray/V2Ray JSON: one config, an array of configs (panel "xray-json" subscriptions) or a bare outbound. */
fun parseXray(json: Any?): ParseResult {
    val cfgs: List<Any?> = if (json is List<*>) json else listOf(json)
    val servers = ArrayList<ParsedServer>(); val errors = ArrayList<String>()
    for (cfg in cfgs) {
        val c = cfg.asMap() ?: continue
        val outs: List<Obj> = when {
            c["outbounds"] is List<*> -> c["outbounds"].asList()!!.mapNotNull { it.asMap() }
            c["protocol"] is String -> listOf(c)
            else -> emptyList()
        }
        val proxies = outs.filter { it["protocol"].asStr() in XRAY_PROXY }
        val remarks = c["remarks"].asStr() ?: c["ps"].asStr()
        proxies.forEachIndexed { i, o ->
            val name = (if (i == 0) remarks else null) ?: o["tag"].asStr() ?: remarks ?: "Xray"
            try { servers.add(xrayConvert(o, name)) } catch (e: ConfigError) { errors.add("${name.take(30)}: ${e.message}") }
        }
    }
    if (servers.isEmpty() && errors.isEmpty()) errors.add("No supported outbounds in the Xray config")
    return ParseResult(servers, errors)
}

// ------------------------------------------------------------------------------------------- WireGuard

fun isWireGuardConf(t: String): Boolean {
    val o = setOf(RegexOption.IGNORE_CASE, RegexOption.MULTILINE)
    return Regex("^\\s*\\[Interface]", o).containsMatchIn(t) && Regex("^\\s*\\[Peer]", o).containsMatchIn(t)
}

fun parseWireGuard(text: String, filename: String = "WireGuard"): ParsedServer {
    class Section(val name: String) { val kv = HashMap<String, String>() }
    val sections = ArrayList<Section>()
    for (raw in text.lines()) {
        val line = raw.replace(Regex("[#;].*$"), "").trim()
        if (line.isEmpty()) continue
        val sec = Regex("^\\[(.+)]$").find(line)
        if (sec != null) { sections.add(Section(sec.groupValues[1].lowercase())); continue }
        val i = line.indexOf('=')
        if (i < 0 || sections.isEmpty()) continue
        sections.last().kv[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
    }
    val iface = sections.firstOrNull { it.name == "interface" }
    val peers = sections.filter { it.name == "peer" }
    val priv = iface?.kv?.get("privatekey"); val addr = iface?.kv?.get("address")
    if (iface == null || priv.isNullOrEmpty() || addr.isNullOrEmpty()) throw ConfigError("bad_config", "WireGuard: [Interface] needs PrivateKey and Address")
    if (peers.isEmpty()) throw ConfigError("bad_config", "WireGuard: no [Peer] section")
    val outPeers = JSONArray(); var firstHost = ""; var firstPort = 0
    for (p in peers) {
        val ep = p.kv["endpoint"]; val pub = p.kv["publickey"]
        if (pub.isNullOrEmpty() || ep.isNullOrEmpty()) throw ConfigError("bad_config", "WireGuard: peer needs PublicKey and Endpoint")
        val c = ep.lastIndexOf(':'); if (c < 0) throw ConfigError("bad_config", "WireGuard: endpoint needs host:port")
        val host = ep.substring(0, c).removeSurrounding("[", "]")
        val port = ep.substring(c + 1).toIntOrNull() ?: throw ConfigError("bad_config", "WireGuard: bad endpoint port")
        outPeers.put(obj("address" to host, "port" to port, "public_key" to pub, "allowed_ips" to (p.kv["allowedips"] ?: "0.0.0.0/0, ::/0").split(',').map { it.trim() },
            "pre_shared_key" to p.kv["presharedkey"], "persistent_keepalive_interval" to p.kv["persistentkeepalive"]?.toIntOrNull()))
        if (firstHost.isEmpty()) { firstHost = host; firstPort = port }
    }
    val ob = obj("type" to "wireguard", "address" to addr.split(',').map { it.trim() }, "private_key" to priv, "peers" to outPeers, "mtu" to iface.kv["mtu"]?.toIntOrNull())
    return ParsedServer(filename.replace(Regex("\\.conf$", RegexOption.IGNORE_CASE), ""), "wireguard", "WireGuard", firstHost, firstPort, ob, "endpoint")
}
