package app.amnezia.client.data

import android.content.Context
import android.os.Build
import app.amnezia.client.config.CoreSettings
import app.amnezia.client.config.ParsedServer
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Server(
    val id: String, val name: String, val protocol: String, val transport: String, val host: String, val port: Int,
    val kind: String, val outbound: String, val group: String, val subscriptionId: String?,
) {
    fun toParsed() = ParsedServer(name, protocol, transport, host, port, JSONObject(outbound), kind)
}

data class Sub(
    val id: String, val url: String, val name: String, val updatedAt: Long, val error: String?,
    val usage: Usage?, val supportUrl: String?, val intervalHours: Int?,
)

data class AppSettings(
    val dns: String = "https://1.1.1.1/dns-query",
    val userAgent: String = "Happ",
    val sendHwid: Boolean = true,
    val hwid: String = "",
    val tlsFragment: Boolean = false,
    val fingerprint: String = "auto",
    val sniffing: Boolean = true,
    val mux: Boolean = false,
    val perAppMode: String = "off",
    val perAppPackages: Set<String> = emptySet(),
) {
    fun core() = CoreSettings(dns = dns, sniffing = sniffing, tlsFragment = tlsFragment, fingerprint = fingerprint, mux = mux)
    fun sub() = SubSettings(userAgent = userAgent, sendHwid = sendHwid, hwid = hwid,
        device = DeviceInfo("Android", Build.VERSION.RELEASE ?: "", Build.MODEL ?: "", Locale.getDefault().language))
}

data class AppState(val servers: List<Server> = emptyList(), val subs: List<Sub> = emptyList(), val selectedId: String? = null, val settings: AppSettings = AppSettings())

/** JSON file in the app's private storage. One instance per process. */
class Repository private constructor(private val file: File) {
    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppState> = _state.asStateFlow()

    private fun load(): AppState {
        val s = try { JSONObject(file.readText()) } catch (_: Exception) { JSONObject() }
        val st = s.optJSONObject("settings") ?: JSONObject()
        val d = AppSettings()
        val settings = AppSettings(
            dns = st.optString("dns", d.dns), userAgent = st.optString("userAgent", d.userAgent), sendHwid = st.optBoolean("sendHwid", d.sendHwid),
            hwid = st.optString("hwid", "").ifEmpty { newHwid() }, tlsFragment = st.optBoolean("tlsFragment", d.tlsFragment),
            fingerprint = st.optString("fingerprint", d.fingerprint), sniffing = st.optBoolean("sniffing", d.sniffing), mux = st.optBoolean("mux", d.mux),
            perAppMode = st.optString("perAppMode", d.perAppMode),
            perAppPackages = st.optJSONArray("perAppPackages")?.let { a -> (0 until a.length()).map { a.getString(it) }.toSet() } ?: emptySet(),
        )
        val servers = s.optJSONArray("servers").objs().map {
            Server(it.getString("id"), it.getString("name"), it.getString("protocol"), it.getString("transport"), it.getString("host"), it.getInt("port"),
                it.optString("kind", "outbound"), it.getString("outbound"), it.optString("group", ""), it.optString("subscriptionId", "").ifEmpty { null })
        }
        val subs = s.optJSONArray("subs").objs().map {
            val u = it.optJSONObject("usage")
            Sub(it.getString("id"), it.getString("url"), it.optString("name", ""), it.optLong("updatedAt", 0), it.optString("error", "").ifEmpty { null },
                u?.let { x -> Usage(x.optLong("upload"), x.optLong("download"), x.optLong("total"), x.optLong("expire")) },
                it.optString("supportUrl", "").ifEmpty { null }, if (it.has("intervalHours")) it.optInt("intervalHours") else null)
        }
        return AppState(servers, subs, s.optString("selectedId", "").ifEmpty { null }, settings)
    }

    private fun JSONArray?.objs(): List<JSONObject> = if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }

    private fun persist(s: AppState) {
        val o = JSONObject()
            .put("selectedId", s.selectedId ?: "")
            .put("settings", JSONObject().put("dns", s.settings.dns).put("userAgent", s.settings.userAgent).put("sendHwid", s.settings.sendHwid)
                .put("hwid", s.settings.hwid).put("tlsFragment", s.settings.tlsFragment).put("fingerprint", s.settings.fingerprint)
                .put("sniffing", s.settings.sniffing).put("mux", s.settings.mux)
                .put("perAppMode", s.settings.perAppMode).put("perAppPackages", JSONArray(s.settings.perAppPackages.toList())))
            .put("servers", JSONArray(s.servers.map {
                JSONObject().put("id", it.id).put("name", it.name).put("protocol", it.protocol).put("transport", it.transport).put("host", it.host)
                    .put("port", it.port).put("kind", it.kind).put("outbound", it.outbound).put("group", it.group).put("subscriptionId", it.subscriptionId ?: "")
            }))
            .put("subs", JSONArray(s.subs.map {
                JSONObject().put("id", it.id).put("url", it.url).put("name", it.name).put("updatedAt", it.updatedAt).put("error", it.error ?: "")
                    .put("supportUrl", it.supportUrl ?: "").apply {
                        it.intervalHours?.let { h -> put("intervalHours", h) }
                        it.usage?.let { u -> put("usage", JSONObject().put("upload", u.upload).put("download", u.download).put("total", u.total).put("expire", u.expire)) }
                    }
            }))
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(o.toString()); tmp.renameTo(file)
    }

    @Synchronized private fun update(f: (AppState) -> AppState) { val n = f(_state.value); _state.value = n; persist(n) }

    init { if (!file.exists()) persist(_state.value) }

    /** Same server twice (same endpoint and credentials) is stored once. */
    private fun key(p: ParsedServer): String {
        val ident = p.outbound.optString("uuid").ifEmpty { p.outbound.optString("password") }
        return sha("${p.protocol}|${p.host}|${p.port}|$ident")
    }
    private fun sha(s: String) = MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun toServer(p: ParsedServer, group: String, subId: String?) =
        Server(key(p).take(16) + (subId?.take(6) ?: ""), p.name, p.protocol, p.transport, p.host, p.port, p.kind, p.outbound.toString(), group, subId)

    /** Adds servers pasted by hand (no subscription). Returns how many were new. */
    fun addServers(list: List<ParsedServer>): Int {
        var added = 0
        update { st ->
            val have = st.servers.map { it.id }.toMutableSet(); val out = st.servers.toMutableList()
            for (p in list) { val s = toServer(p, "", null); if (have.add(s.id)) { out.add(s); added++ } }
            st.copy(servers = out, selectedId = st.selectedId ?: out.firstOrNull()?.id)
        }
        return added
    }

    /** Creates or refreshes a subscription and replaces its servers. */
    fun saveSubscription(url: String, result: SubResult) {
        update { st ->
            val old = st.subs.firstOrNull { it.url == url }
            val id = old?.id ?: UUID.randomUUID().toString()
            val name = result.meta.title ?: old?.name?.ifEmpty { null } ?: runCatching { java.net.URL(url).host }.getOrDefault(url)
            val sub = Sub(id, url, name, System.currentTimeMillis(), null, result.meta.usage, result.meta.supportUrl, result.meta.intervalHours)
            val servers = result.servers.map { toServer(it, name, id) }.distinctBy { it.id }
            val rest = st.servers.filter { it.subscriptionId != id }
            val all = rest + servers
            st.copy(subs = st.subs.filter { it.id != id } + sub, servers = all, selectedId = if (all.any { it.id == st.selectedId }) st.selectedId else all.firstOrNull()?.id)
        }
    }

    fun markSubError(url: String, message: String) = update { st -> st.copy(subs = st.subs.map { if (it.url == url) it.copy(error = message) else it }) }

    fun removeSub(id: String) = update { st ->
        val servers = st.servers.filter { it.subscriptionId != id }
        st.copy(subs = st.subs.filter { it.id != id }, servers = servers, selectedId = if (servers.any { it.id == st.selectedId }) st.selectedId else servers.firstOrNull()?.id)
    }

    fun removeServer(id: String) = update { st ->
        val servers = st.servers.filter { it.id != id }
        st.copy(servers = servers, selectedId = if (st.selectedId == id) servers.firstOrNull()?.id else st.selectedId)
    }

    fun select(id: String) = update { it.copy(selectedId = id) }
    fun updateSettings(f: (AppSettings) -> AppSettings) = update { it.copy(settings = f(it.settings)) }

    companion object {
        @Volatile private var inst: Repository? = null
        fun get(ctx: Context): Repository = inst ?: synchronized(this) { inst ?: Repository(File(ctx.applicationContext.filesDir, "state.json")).also { inst = it } }
    }
}
