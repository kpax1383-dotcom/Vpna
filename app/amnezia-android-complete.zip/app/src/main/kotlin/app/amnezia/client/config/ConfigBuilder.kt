package app.amnezia.client.config

import org.json.JSONArray
import org.json.JSONObject

/** What the config builder needs from the app settings. */
data class CoreSettings(
    val dns: String = "https://1.1.1.1/dns-query",
    val sniffing: Boolean = true,
    val tlsFragment: Boolean = false,
    val fragmentDelayMs: Int = 500,
    val fingerprint: String = "auto",
    val mux: Boolean = false,
    val muxProtocol: String = "h2mux",
)

/** Builds a sing-box (>= 1.12) config for Android: one TUN inbound (the VpnService hands libbox the descriptor), the chosen server as "proxy". */
object ConfigBuilder {
    private val QUIC_TYPES = setOf("hysteria", "hysteria2", "tuic", "wireguard")
    private val MUX_TYPES = setOf("vless", "vmess", "trojan", "shadowsocks")

    /** "1.1.1.1", "https://dns.google/dns-query" or "tls://dns.google" -> sing-box DNS server object. */
    fun dnsServer(spec: String, tag: String, detour: String? = null): JSONObject {
        val s = spec.trim().ifEmpty { "1.1.1.1" }
        val o = JSONObject().put("tag", tag)
        if (detour != null) o.put("detour", detour)
        Regex("^https://([^/]+)(/.*)?$", RegexOption.IGNORE_CASE).find(s)?.let {
            return o.put("type", "https").put("server", it.groupValues[1]).put("path", it.groupValues[2].ifEmpty { "/dns-query" }).put("domain_resolver", "local")
        }
        Regex("^tls://(.+)$", RegexOption.IGNORE_CASE).find(s)?.let {
            return o.put("type", "tls").put("server", it.groupValues[1]).put("domain_resolver", "local")
        }
        return o.put("type", "udp").put("server", s.replace(Regex("^udp://", RegexOption.IGNORE_CASE), ""))
    }

    /** TLS fragmentation, uTLS fingerprint override and multiplexing, applied to the copy of the server outbound. */
    fun applyEvasion(proxy: JSONObject, s: CoreSettings) {
        val type = proxy.optString("type")
        if (type in QUIC_TYPES) return
        val tls = proxy.optJSONObject("tls")
        if (tls != null && tls.optBoolean("enabled")) {
            if (s.tlsFragment) { tls.put("fragment", true); tls.put("fragment_fallback_delay", "${s.fragmentDelayMs}ms") }
            if (s.fingerprint != "auto" && s.fingerprint.isNotEmpty()) tls.put("utls", JSONObject().put("enabled", true).put("fingerprint", s.fingerprint))
        }
        val grpc = proxy.optJSONObject("transport")?.optString("type") == "grpc"
        val muxOk = type in MUX_TYPES && !proxy.has("flow") && !proxy.has("multiplex") && !grpc   // xtls-vision and gRPC cannot be multiplexed
        if (s.mux && muxOk) proxy.put("multiplex", JSONObject().put("enabled", true).put("protocol", s.muxProtocol).put("max_connections", 4))
    }

    fun build(server: ParsedServer, settings: CoreSettings): String {
        val proxy = JSONObject(server.outbound.toString()).put("tag", "proxy")
        if (server.kind == "outbound") applyEvasion(proxy, settings)

        val rules = JSONArray()
        if (settings.sniffing) {
            rules.put(JSONObject().put("action", "sniff"))
            rules.put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))
        } else {
            rules.put(JSONObject().put("port", 53).put("action", "hijack-dns"))
        }
        rules.put(JSONObject().put("ip_is_private", true).put("outbound", "direct"))

        val outbounds = JSONArray().put(JSONObject().put("type", "direct").put("tag", "direct"))
        val cfg = JSONObject()
            .put("log", JSONObject().put("level", "warn").put("timestamp", true))
            .put("dns", JSONObject()
                .put("servers", JSONArray().put(dnsServer(settings.dns, "remote", "proxy")).put(JSONObject().put("type", "local").put("tag", "local")))
                .put("final", "remote"))
            .put("inbounds", JSONArray().put(JSONObject()
                .put("type", "tun").put("tag", "tun-in")
                .put("address", JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
                .put("auto_route", true).put("stack", "mixed")))
            .put("route", JSONObject()
                .put("default_domain_resolver", "local").put("final", "proxy")
                .put("auto_detect_interface", true).put("rules", rules))
        if (server.kind == "endpoint") { cfg.put("endpoints", JSONArray().put(proxy)); cfg.put("outbounds", outbounds) }
        else { cfg.put("outbounds", JSONArray().put(proxy).put(outbounds.getJSONObject(0))) }
        return cfg.toString()
    }
}
