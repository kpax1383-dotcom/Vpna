package app.amnezia.client.ui

import android.widget.Toast
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.amnezia.client.R
import app.amnezia.client.data.AppState
import app.amnezia.client.data.Server
import app.amnezia.client.data.Sub
import app.amnezia.client.vpn.Phase
import app.amnezia.client.vpn.VpnState
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date

@Composable
fun App(vm: AppViewModel, onPower: () -> Unit, onPickFile: () -> Unit) {
    val state by vm.state.collectAsState()
    val status by VpnState.status.collectAsState()
    val msg by vm.message.collectAsState()
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(0) }
    var showAdd by rememberSaveable { mutableStateOf(false) }

    val msgText = when (val m = msg) {
        is Msg.Text -> m.text
        is Msg.Added -> stringResource(R.string.added_n, m.n)
        is Msg.Refreshed -> stringResource(R.string.refreshed_n, m.n)
        Msg.PingBlocked -> stringResource(R.string.ping_blocked)
        Msg.FileFailed -> stringResource(R.string.open_file_failed)
        null -> null
    }
    LaunchedEffect(msgText) { if (msgText != null) { Toast.makeText(ctx, msgText, Toast.LENGTH_LONG).show(); vm.message.value = null } }
    LaunchedEffect(status.phase) { if (status.phase == Phase.Error && status.message != null) Toast.makeText(ctx, status.message, Toast.LENGTH_LONG).show() }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Palette.Bg2, Palette.Bg))).systemBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeScreen(state, status.phase, status.since, onPower, onAdd = { showAdd = true }, onPick = { tab = 1 })
                    1 -> ServersScreen(vm, state, onAdd = { showAdd = true })
                    else -> SettingsScreen(vm, state)
                }
            }
            BottomBar(tab) { tab = it }
        }
    }
    if (showAdd) AddDialog(onDismiss = { showAdd = false }, onAdd = { vm.add(it); showAdd = false }, onFile = { showAdd = false; onPickFile() })
}

@Composable
private fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    val labels = listOf(R.string.tab_home, R.string.tab_servers, R.string.tab_settings)
    Row(Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(22.dp)).background(Palette.Card).border(1.dp, Palette.CardBorder, RoundedCornerShape(22.dp)).padding(6.dp)) {
        labels.forEachIndexed { i, l ->
            val on = tab == i
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (on) Palette.Accent.copy(alpha = 0.22f) else Color.Transparent)
                    .clickable { onTab(i) }.padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) { Text(stringResource(l), color = if (on) Palette.Accent2 else Palette.Muted, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, fontSize = 14.sp) }
        }
    }
}

@Composable
private fun HomeScreen(state: AppState, phase: Phase, since: Long, onPower: () -> Unit, onAdd: () -> Unit, onPick: () -> Unit) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(phase) { while (phase == Phase.On) { now = System.currentTimeMillis(); delay(1000) } }
    val server = state.servers.firstOrNull { it.id == state.selectedId }
    val traffic by VpnState.traffic.collectAsState()

    Box(Modifier.fillMaxSize()) {
        TextButton(onClick = onAdd, modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)) { Text("+", fontSize = 30.sp, color = Palette.Text) }
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            PowerOrb(phase, onPower)
            Spacer(Modifier.height(24.dp))
            Text(
                stringResource(when (phase) { Phase.Off -> R.string.status_off; Phase.Connecting -> R.string.status_connecting; Phase.On -> R.string.status_on; Phase.Error -> R.string.status_error }),
                color = if (phase == Phase.Error) Palette.Danger else Palette.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
            )
            if (phase == Phase.On) {
                val s = ((now - since) / 1000).coerceAtLeast(0)
                Text("%02d:%02d:%02d".format(s / 3600, s / 60 % 60, s % 60), color = Palette.Muted, fontSize = 16.sp)
                if (traffic.available) {
                    Text("↓ ${bytes(traffic.downSpeed)}/s   ↑ ${bytes(traffic.upSpeed)}/s", color = Palette.Text, fontSize = 15.sp, modifier = Modifier.padding(top = 10.dp))
                    Text("↓ ${bytes(traffic.down)}   ↑ ${bytes(traffic.up)}", color = Palette.Muted, fontSize = 13.sp)
                } else Text(stringResource(R.string.traffic_na), color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            }
            Spacer(Modifier.height(32.dp))
            Card(Modifier.clickable { onPick() }) {
                if (server == null) Text(stringResource(R.string.no_server), color = Palette.Muted)
                else Column {
                    Text(server.name, color = Palette.Text, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${server.protocol.uppercase()} · ${server.transport}", color = Palette.Muted, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun PowerOrb(phase: Phase, onClick: () -> Unit) {
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.94f, targetValue = 1.06f, animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p",
    )
    val color = when (phase) { Phase.On -> Palette.Accent; Phase.Connecting -> Palette.Accent2; Phase.Error -> Palette.Danger; Phase.Off -> Color(0xFF454B66) }
    Box(
        Modifier.size(230.dp).scale(if (phase == Phase.Connecting) pulse else 1f).clip(CircleShape)
            .background(Brush.radialGradient(listOf(color.copy(alpha = 0.32f), Color.Transparent)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(150.dp).clip(CircleShape).background(Palette.Card).border(1.dp, color.copy(alpha = 0.6f), CircleShape), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(64.dp)) {
                val w = 7.dp.toPx(); val inset = w / 2
                drawArc(color, startAngle = -60f, sweepAngle = 300f, useCenter = false, topLeft = Offset(inset, inset), size = Size(size.width - w, size.height - w), style = Stroke(w, cap = StrokeCap.Round))
                drawLine(color, Offset(size.width / 2, 0f + inset), Offset(size.width / 2, size.height / 2), strokeWidth = w, cap = StrokeCap.Round)
            }
        }
    }
}

@Composable
private fun Card(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Palette.Card).border(BorderStroke(1.dp, Palette.CardBorder), RoundedCornerShape(18.dp)).padding(16.dp)) { content() }
}

@Composable
private fun ServersScreen(vm: AppViewModel, state: AppState, onAdd: () -> Unit) {
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    val pings by vm.pings.collectAsState()
    val pinging by vm.pinging.collectAsState()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.subscriptions), color = Palette.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = onAdd) { Text("+", fontSize = 28.sp, color = Palette.Text) }
        } }
        items(state.subs, key = { it.id }) { sub -> SubCard(vm, sub, fmt) }
        item { Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.servers), color = Palette.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = { vm.measurePings() }, enabled = !pinging) { Text(stringResource(R.string.ping), color = Palette.Accent2) }
        } }
        items(state.servers, key = { it.id }) { s ->
            val ping = if (pings.containsKey(s.id)) (pings[s.id]?.let { "$it ms" } ?: "—") else null
            ServerRow(s, s.id == state.selectedId, ping, onSelect = { vm.repo.select(s.id) }, onDelete = { vm.repo.removeServer(s.id) })
        }
    }
}

private fun bytes(n: Long): String {
    if (n <= 0) return "0"
    val u = listOf("B", "KB", "MB", "GB", "TB"); var v = n.toDouble(); var i = 0
    while (v >= 1024 && i < u.lastIndex) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}

@Composable
private fun SubCard(vm: AppViewModel, sub: Sub, fmt: DateFormat) {
    Card {
        Column {
            Text(sub.name, color = Palette.Text, fontWeight = FontWeight.SemiBold)
            Text(stringResource(R.string.updated, fmt.format(Date(sub.updatedAt))), color = Palette.Muted, fontSize = 13.sp)
            sub.usage?.takeIf { it.total > 0 }?.let { Text(stringResource(R.string.usage, bytes(it.upload + it.download), bytes(it.total)), color = Palette.Muted, fontSize = 13.sp) }
            sub.error?.let { Text(it, color = Palette.Danger, fontSize = 13.sp) }
            Row {
                TextButton(onClick = { vm.refresh(sub) }) { Text(stringResource(R.string.refresh), color = Palette.Accent2) }
                TextButton(onClick = { vm.repo.removeSub(sub.id) }) { Text(stringResource(R.string.delete), color = Palette.Danger) }
            }
        }
    }
}

@Composable
private fun ServerRow(s: Server, selected: Boolean, ping: String?, onSelect: () -> Unit, onDelete: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(if (selected) Palette.Accent.copy(alpha = 0.16f) else Palette.Card)
            .border(1.dp, if (selected) Palette.Accent else Palette.CardBorder, shape).clickable { onSelect() }.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(s.name, color = Palette.Text, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${s.protocol.uppercase()} · ${s.transport} · ${s.host}:${s.port}", color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (ping != null) Text(ping, color = if (ping == "—") Palette.Danger else Palette.Accent2, fontSize = 13.sp)
        TextButton(onClick = onDelete) { Text("✕", color = Palette.Muted) }
    }
}

@Composable
private fun SettingsScreen(vm: AppViewModel, state: AppState) {
    val s = state.settings
    var showApps by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(stringResource(R.string.tab_settings), color = Palette.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        var dns by remember(s.dns) { mutableStateOf(s.dns) }
        OutlinedTextField(dns, { dns = it }, label = { Text(stringResource(R.string.s_dns)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        TextButton(onClick = { vm.repo.updateSettings { it.copy(dns = dns.trim().ifEmpty { "1.1.1.1" }) } }) { Text(stringResource(R.string.add_button), color = Palette.Accent2) }

        Text(stringResource(R.string.s_ua), color = Palette.Muted, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (ua in listOf("Happ", "sing-box", "v2rayN")) {
                if (s.userAgent == ua) Button(onClick = {}) { Text(ua) }
                else OutlinedButton(onClick = { vm.repo.updateSettings { it.copy(userAgent = ua) } }) { Text(ua) }
            }
        }
        SwitchRow(R.string.s_hwid_send, s.sendHwid) { v -> vm.repo.updateSettings { it.copy(sendHwid = v) } }
        SelectionContainer { Text(stringResource(R.string.s_hwid_value, s.hwid), color = Palette.Muted, fontSize = 13.sp) }
        SwitchRow(R.string.s_fragment, s.tlsFragment) { v -> vm.repo.updateSettings { it.copy(tlsFragment = v) } }
        SwitchRow(R.string.s_mux, s.mux) { v -> vm.repo.updateSettings { it.copy(mux = v) } }
        SwitchRow(R.string.s_sniff, s.sniffing) { v -> vm.repo.updateSettings { it.copy(sniffing = v) } }
        OutlinedButton(onClick = { showApps = true }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.per_app) + if (s.perAppMode != "off") " (${s.perAppPackages.size})" else "") }
        OutlinedButton(onClick = { showLog = true }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.log)) }
    }
    if (showApps) PerAppDialog(vm, state) { showApps = false }
    if (showLog) LogDialog { showLog = false }
}

@Composable
private fun SwitchRow(label: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    Card { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(label), color = Palette.Text, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    } }
}

@Composable
private fun AddDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit, onFile: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.add_title)) },
        text = {
            Column {
                OutlinedTextField(text, { text = it }, placeholder = { Text(stringResource(R.string.add_hint), fontSize = 13.sp) }, minLines = 3, maxLines = 8, modifier = Modifier.fillMaxWidth())
                Row {
                    TextButton(onClick = { clipboard.getText()?.text?.let { text = it } }) { Text(stringResource(R.string.add_paste), color = Palette.Accent2) }
                    TextButton(onClick = onFile) { Text(stringResource(R.string.file_button), color = Palette.Accent2) }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onAdd(text) }) { Text(stringResource(R.string.add_button)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun PerAppDialog(vm: AppViewModel, state: AppState, onDismiss: () -> Unit) {
    LaunchedEffect(Unit) { vm.loadApps() }
    val apps by vm.apps.collectAsState()
    var query by remember { mutableStateOf("") }
    val s = state.settings
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Palette.Bg).systemBarsPadding().padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.per_app), color = Palette.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.close), color = Palette.Accent2) }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for ((mode, label) in listOf("off" to R.string.per_app_off, "include" to R.string.per_app_include, "exclude" to R.string.per_app_exclude)) {
                    if (s.perAppMode == mode) Button(onClick = {}, modifier = Modifier.weight(1f)) { Text(stringResource(label), fontSize = 12.sp, maxLines = 1) }
                    else OutlinedButton(onClick = { vm.repo.updateSettings { it.copy(perAppMode = mode) } }, modifier = Modifier.weight(1f)) { Text(stringResource(label), fontSize = 12.sp, maxLines = 1) }
                }
            }
            Text(stringResource(R.string.per_app_hint), color = Palette.Muted, fontSize = 12.sp)
            OutlinedTextField(query, { query = it }, placeholder = { Text(stringResource(R.string.search)) }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
            val list = apps?.filter { query.isBlank() || it.label.contains(query, ignoreCase = true) || it.pkg.contains(query, ignoreCase = true) }
            if (list == null) Text("…", color = Palette.Muted)
            else LazyColumn(Modifier.weight(1f)) {
                items(list, key = { it.pkg }) { a ->
                    val on = a.pkg in s.perAppPackages
                    val toggle = { vm.repo.updateSettings { st -> st.copy(perAppPackages = if (on) st.perAppPackages - a.pkg else st.perAppPackages + a.pkg) } }
                    Row(Modifier.fillMaxWidth().clickable { toggle() }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = on, onCheckedChange = { toggle() })
                        Column { Text(a.label, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(a.pkg, color = Palette.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    }
                }
            }
        }
    }
}

@Composable
private fun LogDialog(onDismiss: () -> Unit) {
    val lines by VpnState.log.collectAsState()
    val clipboard = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.log)) },
        text = {
            Column(Modifier.height(360.dp).verticalScroll(rememberScrollState(), reverseScrolling = true)) {
                SelectionContainer { Text(lines.joinToString("\n").ifEmpty { "—" }, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Palette.Muted) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) } },
        dismissButton = {
            Row {
                TextButton(onClick = { clipboard.setText(AnnotatedString(lines.joinToString("\n"))) }) { Text(stringResource(R.string.copy)) }
                TextButton(onClick = { VpnState.clearLog() }) { Text(stringResource(R.string.clear)) }
            }
        },
    )
}
