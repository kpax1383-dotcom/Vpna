package app.amnezia.client.vpn

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class Phase { Off, Connecting, On, Error }

data class VpnStatus(val phase: Phase = Phase.Off, val since: Long = 0, val message: String? = null)

/** Bytes moved by the tunnel since it started, and the current speed (bytes/s). [available] is false when the device does not report per-app traffic. */
data class Traffic(val down: Long = 0, val up: Long = 0, val downSpeed: Long = 0, val upSpeed: Long = 0, val available: Boolean = true)

/** Process-wide connection state, written by the service and read by the UI. */
object VpnState {
    private val _status = MutableStateFlow(VpnStatus())
    val status: StateFlow<VpnStatus> = _status.asStateFlow()
    fun set(s: VpnStatus) { _status.value = s }

    private val _traffic = MutableStateFlow(Traffic())
    val traffic: StateFlow<Traffic> = _traffic.asStateFlow()
    fun setTraffic(t: Traffic) { _traffic.value = t }

    private val _log = MutableStateFlow<List<String>>(emptyList())
    val log: StateFlow<List<String>> = _log.asStateFlow()
    @Synchronized fun log(line: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        _log.value = (_log.value + "$t  ${line.trimEnd()}").takeLast(400)
    }
    fun clearLog() { _log.value = emptyList() }
}
