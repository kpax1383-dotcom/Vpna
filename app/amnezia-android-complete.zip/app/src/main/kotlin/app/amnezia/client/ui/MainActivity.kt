package app.amnezia.client.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import app.amnezia.client.vpn.Phase
import app.amnezia.client.vpn.TunService
import app.amnezia.client.vpn.VpnState

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { if (it.resultCode == RESULT_OK) startTunnel() }
    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) importFile(uri) }
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* the VPN works without notifications */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleDeepLink(intent)
        setContent { AmneziaTheme { App(vm, ::onPower, onPickFile = { pickFile.launch(arrayOf("*/*")) }) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleDeepLink(intent)
    }

    /** happ://add/<url> and amnezia://add/<url> */
    private fun handleDeepLink(i: Intent?) {
        if (i?.action == Intent.ACTION_VIEW) i.data?.let { vm.add(it.toString()) }
    }

    /** WireGuard .conf, Clash .yaml, Xray/sing-box .json or a text file with links. */
    private fun importFile(uri: android.net.Uri) {
        try {
            val name = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw java.io.IOException("empty")
            if (bytes.size > 2_000_000) throw java.io.IOException("too large")
            vm.add(String(bytes, Charsets.UTF_8), name)
        } catch (_: Exception) { vm.message.value = Msg.FileFailed }
    }

    private fun onPower() {
        val phase = VpnState.status.value.phase
        if (phase == Phase.On || phase == Phase.Connecting) {
            startService(Intent(this, TunService::class.java).setAction(TunService.ACTION_STOP))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val ask = VpnService.prepare(this)
        if (ask != null) vpnPermission.launch(ask) else startTunnel()
    }

    private fun startTunnel() {
        ContextCompat.startForegroundService(this, Intent(this, TunService::class.java).setAction(TunService.ACTION_START))
    }
}
