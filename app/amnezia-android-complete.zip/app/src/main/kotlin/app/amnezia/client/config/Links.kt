package app.amnezia.client.config

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.util.Base64

class ConfigError(val code: String, message: String) : Exception(message)

/** One server as sing-box wants it: [outbound] is the sing-box outbound (or endpoint) object without a tag. */
data class ParsedServer(
    val name: String,
    val protocol: String,
    val transport: String,
    val host: String,
    val port: Int,
    val outbound: JSONObject,
    val kind: String = "outbound",
)

data class ParseResult(val servers: List<ParsedServer>, val errors: List<String>)

/** JSON object that skips null, empty strings and empty lists (same rule as `clean()` in the desktop app). */
internal fun obj(vararg p: Pair<String, Any?>): JSONObject {
    val o = JSONObject()
    for ((k, v) in p) {
        if (v == null || v == "" || (v is List<*> && v.isEmpty()) || (v is JSONArray && v.length() == 0)) continue
        o.put(k, if (v is List<*>) JSONArray(v) else v)
    }
    return o
}

/** decodeURIComponent: '+' stays a plus. */
internal fun dec(s: String): String = try { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") } catch (_: Exception) { s }

/** URLSearchParams decoding: '+' is a space. */
private fun decForm(s: String): String = try { URLDecoder.decode(s, "UTF-8") } catch (_: Exception) { s }

internal fun b64decode(s: String): String {
    val norm = s.replace('-', '+').replace('_', '/').filterNot { it.isWhitespace() }
    val padded = norm + "=".repeat((4 - norm.length % 4) % 4)
    return String(Base64.getDecoder().decode(padded), Charsets.UTF_8)
}

private fun parseQuery(raw: String): Map<String, String> {
    if (raw.isEmpty()) return emptyMap()
    val m = LinkedHashMap<String, String>()
    for (part in raw.split('&')) {
        if (part.isEmpty()) continue
        m.putIfAbsent(decForm(part.substringBefore('=')), decForm(part.substringAfter('=', "")))
    }
    return m
}

private fun Map<String, String>.nz(k: String): String? = this[k]?.takeIf { it.isNotEmpty() }

private class Link(val user: String, val pass: String?, val host: String, val port: Int?, val query: Map<String, String>, val fragment: String)

private fun split(link: String): Link {
    if (!link.contains("://")) throw ConfigError("bad_link", "Malformed link")
    val rest = link.substringAfter("://")
    val fragment = dec(rest.substringAfter('#', ""))
    val noFrag = rest.substringBefore('#')
    val query = parseQuery(noFrag.substringAfter('?', ""))
    val auth = noFrag.substringBefore('?').substringBefore('/')
    val at = auth.lastIndexOf('@')
    val userinfo = if (at >= 0) auth.substring(0, at) else ""
    val hostport = if (at >= 0) auth.substring(at + 1) else auth
    val host: String
    val port: Int?
    if (hostport.startsWith("[")) {
        val end = hostport.indexOf(']')
        if (end < 0) throw ConfigError("bad_link", "Malformed link")
        host = hostport.substring(1, end)
        port = hostport.substring(end + 1).removePrefix(":").toIntOrNull()
    } else {
        val c = hostport.lastIndexOf(':')
        if (c >= 0) { host = hostport.substring(0, c); port = hostport.substring(c + 1).toIntOrNull() } else { host = hostport; port = null }
    }
    if (host.isEmpty()) throw ConfigError("bad_link", "Malformed link")
    val colon = userinfo.indexOf(':')
    val user = if (colon >= 0) userinfo.substring(0, colon) else userinfo
    val pass = if (colon >= 0) userinfo.substring(colon + 1) else null
    return Link(dec(user), pass?.let { dec(it) }, host, port, query, fragment)
}

private fun num(v: Int?, def: Int): Int = if (v != null && v in 1..65535) v else def

private fun tlsFrom(q: Map<String, String>, host: String, force: Boolean = false): JSONObject? {
    val sec = q["security"] ?: if (force) "tls" else "none"
    if (sec == "none" || sec.isEmpty()) return null
    val tls = obj(
        "enabled" to true,
        "server_name" to (q.nz("sni") ?: q.nz("peer") ?: q.nz("host") ?: host),
        "insecure" to if (q["allowInsecure"] == "1" || q["insecure"] == "1") true else null,
        "alpn" to q.nz("alpn")?.split(','),
    )
    val fp = q.nz("fp")
    if (sec == "reality") {
        tls.put("reality", obj("enabled" to true, "public_key" to q["pbk"], "short_id" to q["sid"]))
        tls.put("utls", obj("enabled" to true, "fingerprint" to (fp ?: "chrome")))
    } else if (fp != null) {
        tls.put("utls", obj("enabled" to true, "fingerprint" to fp))
    }
    return tls
}

private fun transportFrom(q: Map<String, String>): Pair<JSONObject?, String> {
    val type = (q["type"] ?: "tcp").lowercase()
    val path = q.nz("path")?.let { dec(it) }
    val hostHdr = q.nz("host")?.let { dec(it) }
    return when (type) {
        "tcp", "raw", "" -> {
            if (q["headerType"] == "http") throw ConfigError("unsupported", "TCP with HTTP header obfuscation is not supported")
            Pair(null, "TCP")
        }
        "ws" -> Pair(obj("type" to "ws", "path" to path, "headers" to hostHdr?.let { obj("Host" to it) }), "WS")
        "grpc" -> Pair(obj("type" to "grpc", "service_name" to (q.nz("serviceName") ?: path)), "gRPC")
        "httpupgrade" -> Pair(obj("type" to "httpupgrade", "path" to path, "host" to hostHdr), "HTTPUpgrade")
        "h2", "http" -> Pair(obj("type" to "http", "path" to path, "host" to hostHdr?.split(',')), "HTTP")
        "xhttp", "splithttp" -> throw ConfigError("unsupported", "XHTTP transport is not supported by the sing-box core")
        else -> throw ConfigError("unsupported", "Unsupported transport: $type")
    }
}

fun parseVless(link: String): ParsedServer {
    val u = split(link); val q = u.query
    val port = num(u.port, 443)
    val (transport, label) = transportFrom(q)
    val tls = tlsFrom(q, u.host)
    val tlabel = when (q["security"]) { "reality" -> "$label Reality"; "tls" -> "$label TLS"; else -> label }
    return ParsedServer(
        u.fragment.ifEmpty { "${u.host}:$port" }, "vless", tlabel, u.host, port,
        obj("type" to "vless", "server" to u.host, "server_port" to port, "uuid" to u.user, "flow" to q["flow"], "packet_encoding" to "xudp", "tls" to tls, "transport" to transport),
    )
}

fun parseTrojan(link: String): ParsedServer {
    val u = split(link); val q = u.query
    val port = num(u.port, 443)
    val (transport, label) = transportFrom(q)
    val tls = tlsFrom(q, u.host, force = true)
    return ParsedServer(
        u.fragment.ifEmpty { "${u.host}:$port" }, "trojan", "$label TLS", u.host, port,
        obj("type" to "trojan", "server" to u.host, "server_port" to port, "password" to u.user, "tls" to tls, "transport" to transport),
    )
}

fun parseVmess(link: String): ParsedServer {
    val j = try {
        JSONObject(b64decode(link.replace(Regex("^vmess://", RegexOption.IGNORE_CASE), "")))
    } catch (_: Exception) { throw ConfigError("bad_link", "Malformed vmess link") }
    val host = j.optString("add", "")
    val port = num(j.opt("port")?.toString()?.toIntOrNull(), 443)
    val id = j.optString("id", "")
    if (host.isEmpty() || id.isEmpty()) throw ConfigError("bad_link", "vmess link is missing address or id")
    val q = LinkedHashMap<String, String>()
    q["type"] = j.optString("net", "tcp").ifEmpty { "tcp" }
    for ((from, to) in listOf("host" to "host", "path" to "path", "sni" to "sni", "alpn" to "alpn", "fp" to "fp")) {
        j.optString(from, "").takeIf { it.isNotEmpty() }?.let { q[to] = it }
    }
    if (j.optString("type", "") == "http") q["headerType"] = "http"
    if (j.optString("tls", "") == "tls") q["security"] = "tls"
    val (transport, label) = transportFrom(q)
    val tls = tlsFrom(q, host)
    return ParsedServer(
        j.optString("ps", "").ifEmpty { "$host:$port" }, "vmess", if (tls != null) "$label TLS" else label, host, port,
        obj("type" to "vmess", "server" to host, "server_port" to port, "uuid" to id, "security" to j.optString("scy", "auto").ifEmpty { "auto" },
            "alter_id" to j.optInt("aid", 0), "tls" to tls, "transport" to transport),
    )
}

private data class SsParts(val method: String, val password: String, val host: String, val port: Int)

fun parseShadowsocks(link: String): ParsedServer {
    var rest = link.replace(Regex("^ss://", RegexOption.IGNORE_CASE), "")
    var name = ""
    val h = rest.indexOf('#'); if (h >= 0) { name = dec(rest.substring(h + 1)); rest = rest.substring(0, h) }
    var query = ""
    val qi = rest.indexOf('?'); if (qi >= 0) { query = rest.substring(qi + 1); rest = rest.substring(0, qi) }
    rest = rest.removeSuffix("/")
    val p = try {
        val at = rest.lastIndexOf('@')
        val userinfo: String
        val hp: String
        if (at >= 0) {
            val ui = rest.substring(0, at)
            userinfo = if (!ui.contains(':')) b64decode(ui) else dec(ui)
            hp = rest.substring(at + 1)
        } else {
            val d = b64decode(rest); val a = d.lastIndexOf('@')
            userinfo = d.substring(0, a); hp = d.substring(a + 1)
        }
        val c = userinfo.indexOf(':'); val pc = hp.lastIndexOf(':')
        SsParts(userinfo.substring(0, c), userinfo.substring(c + 1), hp.substring(0, pc).removeSurrounding("[", "]"), num(hp.substring(pc + 1).toIntOrNull(), 8388))
    } catch (_: Exception) { throw ConfigError("bad_link", "Malformed ss link") }
    if (p.method.isEmpty() || p.host.isEmpty()) throw ConfigError("bad_link", "Malformed ss link")
    val plugin = parseQuery(query)["plugin"]
    val pluginName = plugin?.substringBefore(';')
    val pluginOpts = if (plugin != null && plugin.contains(';')) plugin.substringAfter(';') else null
    return ParsedServer(
        name.ifEmpty { "${p.host}:${p.port}" }, "shadowsocks", if (pluginName != null) "SS $pluginName" else "Shadowsocks", p.host, p.port,
        obj("type" to "shadowsocks", "server" to p.host, "server_port" to p.port, "method" to p.method, "password" to p.password, "plugin" to pluginName, "plugin_opts" to pluginOpts),
    )
}

fun parseHysteria2(link: String): ParsedServer {
    val u = split(link.replace(Regex("^hy2://", RegexOption.IGNORE_CASE), "hysteria2://")); val q = u.query
    val port = num(u.port, 443)
    val password = u.user + (if (u.pass != null) ":" + u.pass else "")
    val obfs = q.nz("obfs")
    val mport = q.nz("mport")
    return ParsedServer(
        u.fragment.ifEmpty { "${u.host}:$port" }, "hysteria2", if (obfs != null) "Hysteria2 Obfs" else "Hysteria2", u.host, port,
        obj(
            "type" to "hysteria2", "server" to u.host, "server_port" to port,
            "server_ports" to mport?.split(',')?.map { it.replace('-', ':') },
            "password" to password,
            "obfs" to obfs?.let { obj("type" to it, "password" to q["obfs-password"]) },
            "tls" to obj("enabled" to true, "server_name" to (q.nz("sni") ?: u.host),
                "insecure" to if (q["insecure"] == "1" || q["allowInsecure"] == "1") true else null, "alpn" to listOf("h3")),
        ),
    )
}

fun parseSocksLink(link: String): ParsedServer {
    val u = split(link.replace(Regex("^socks5?://", RegexOption.IGNORE_CASE), "socks://"))
    val port = num(u.port, 1080)
    return ParsedServer(
        u.fragment.ifEmpty { "${u.host}:$port" }, "socks", "SOCKS5", u.host, port,
        obj("type" to "socks", "server" to u.host, "server_port" to port, "version" to "5", "username" to u.user, "password" to u.pass),
    )
}

private val PARSERS: List<Pair<Regex, (String) -> ParsedServer>> = listOf(
    Regex("^vless://", RegexOption.IGNORE_CASE) to ::parseVless,
    Regex("^vmess://", RegexOption.IGNORE_CASE) to ::parseVmess,
    Regex("^trojan://", RegexOption.IGNORE_CASE) to ::parseTrojan,
    Regex("^ss://", RegexOption.IGNORE_CASE) to ::parseShadowsocks,
    Regex("^(hysteria2|hy2)://", RegexOption.IGNORE_CASE) to ::parseHysteria2,
    Regex("^socks5?://", RegexOption.IGNORE_CASE) to ::parseSocksLink,
)

fun isServerLink(line: String): Boolean = PARSERS.any { it.first.containsMatchIn(line) }

fun parseLink(link: String): ParsedServer {
    val l = link.trim()
    for ((re, fn) in PARSERS) if (re.containsMatchIn(l)) return fn(l)
    val scheme = Regex("^([a-z0-9+.-]+)://", RegexOption.IGNORE_CASE).find(l)?.groupValues?.get(1)
    throw ConfigError("unsupported", if (scheme != null) "Unsupported link type: $scheme://" else "Not a server link")
}

private val SB_TYPES = setOf("vless", "vmess", "trojan", "shadowsocks", "hysteria2", "socks", "http")

private fun fromSingBoxJson(json: JSONObject): ParseResult {
    val items = ArrayList<JSONObject>()
    for (key in listOf("outbounds", "endpoints")) {
        val a = json.optJSONArray(key) ?: continue
        for (i in 0 until a.length()) a.optJSONObject(i)?.let { items.add(it) }
    }
    val servers = ArrayList<ParsedServer>()
    for (o in items) {
        val type = o.optString("type", "")
        if (type !in SB_TYPES && type != "wireguard") continue
        val peer = o.optJSONArray("peers")?.optJSONObject(0)
        val host = o.optString("server", "").ifEmpty { peer?.optString("address", "") ?: "" }
        val port = if (o.has("server_port")) o.optInt("server_port", 0) else peer?.optInt("port", 0) ?: 0
        val copy = JSONObject(o.toString()); copy.remove("tag")
        servers.add(ParsedServer(o.optString("tag", "").ifEmpty { "$host:$port" }, type, type, host, port, copy, if (type == "wireguard") "endpoint" else "outbound"))
    }
    return if (servers.isEmpty()) ParseResult(emptyList(), listOf("No supported outbounds in the sing-box config")) else ParseResult(servers, emptyList())
}

private fun looksBase64(s: String): Boolean = Regex("^[A-Za-z0-9+/=_\\-\\s]+$").matches(s) && s.count { !it.isWhitespace() } >= 16

/** Detects the content type (WireGuard .conf, sing-box / Xray JSON, Clash YAML, links list, base64 of a list) and parses it. OpenVPN files are desktop-only. */
fun parseText(text: String, filename: String? = null): ParseResult {
    val t = text.removePrefix("\uFEFF").trim()
    if (t.isEmpty()) return ParseResult(emptyList(), listOf("Empty content"))
    if (isWireGuardConf(t)) {
        return try { ParseResult(listOf(parseWireGuard(t, filename ?: "WireGuard")), emptyList()) } catch (e: ConfigError) { ParseResult(emptyList(), listOf(e.message ?: "Invalid WireGuard config")) }
    }
    if (Regex("^\\s*(client|remote\\s+\\S+\\s+\\d+|dev\\s+tun)\\b", RegexOption.MULTILINE).containsMatchIn(t) && t.contains("remote ")) {
        return ParseResult(emptyList(), listOf("OpenVPN profiles are not supported on Android yet"))
    }
    if (t.startsWith("{") || t.startsWith("[")) {
        val value = try { org.json.JSONTokener(t).nextValue() } catch (_: Exception) { return ParseResult(emptyList(), listOf("Invalid JSON")) }
        val k = jsonToKotlin(value)
        return try {
            when {
                isXrayJson(k) -> parseXray(k)
                value is JSONObject -> fromSingBoxJson(value)
                else -> ParseResult(emptyList(), listOf("Unsupported JSON format (sing-box and Xray configs are supported)"))
            }
        } catch (_: Exception) { ParseResult(emptyList(), listOf("Unsupported JSON format (sing-box and Xray configs are supported)")) }
    }
    if (isClashYaml(t)) return parseClash(t)
    var body = t
    if (!body.contains("://") && looksBase64(body)) body = try { b64decode(body) } catch (_: Exception) { body }
    val servers = ArrayList<ParsedServer>(); val errors = ArrayList<String>()
    for (line in body.lines().map { it.trim() }.filter { it.isNotEmpty() }) {
        if (!isServerLink(line)) { if (line.contains("://")) errors.add("Skipped: ${line.take(24)}… (unsupported link type)"); continue }
        try { servers.add(parseLink(line)) } catch (e: ConfigError) { errors.add("${e.message} (${line.take(18)}…)") } catch (e: Exception) { errors.add("Parse error (${line.take(18)}…)") }
    }
    if (servers.isEmpty() && errors.isEmpty()) errors.add("No servers found in the content")
    return ParseResult(servers, errors)
}
