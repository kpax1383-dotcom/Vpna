package app.amnezia.client.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.net.TrafficStats
import android.os.Build
import android.os.Process
import androidx.core.app.NotificationCompat
import app.amnezia.client.R
import app.amnezia.client.config.ConfigBuilder
import app.amnezia.client.data.Repository
import app.amnezia.client.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class TunService : VpnService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var core: VpnCore? = null
    private var statsJob: Job? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopTunnel()
            else -> startTunnel(intent?.getStringExtra(EXTRA_SERVER_ID))
        }
        return START_NOT_STICKY
    }

    private fun startTunnel(serverId: String?) {
        goForeground()
        VpnState.set(VpnStatus(Phase.Connecting))
        scope.launch {
            try {
                val repo = Repository.get(applicationContext)
                val st = repo.state.value
                val server = st.servers.firstOrNull { it.id == (serverId ?: st.selectedId) } ?: error("No server selected")
                val config = ConfigBuilder.build(server.toParsed(), st.settings.core())
                val perApp = PerApp(st.settings.perAppMode, st.settings.perAppPackages)
                VpnState.log("Connecting to ${server.name} (${server.protocol}, ${server.host}:${server.port})" + if (perApp.mode != "off") ", per-app: ${perApp.mode} ${perApp.packages.size}" else "")
                core?.stop()
                core = CoreFactory.create(this@TunService, perApp) { VpnState.log(it) }.also { it.start(config) }
                VpnState.set(VpnStatus(Phase.On, since = System.currentTimeMillis()))
                VpnState.log("Connected")
                startStats()
            } catch (e: Throwable) {
                VpnState.log("Error: ${e.message ?: e.javaClass.simpleName}")
                VpnState.set(VpnStatus(Phase.Error, message = e.message ?: e.javaClass.simpleName))
                stopTunnel(keepError = true)
            }
        }
    }

    /** Session traffic from the app's own socket counters: the core sends everything through this process, so this is what the tunnel really moved (including protocol overhead). */
    private fun startStats() {
        statsJob?.cancel()
        statsJob = scope.launch {
            val uid = Process.myUid()
            val rx0 = TrafficStats.getUidRxBytes(uid); val tx0 = TrafficStats.getUidTxBytes(uid)
            if (rx0 == TrafficStats.UNSUPPORTED.toLong() || tx0 == TrafficStats.UNSUPPORTED.toLong()) { VpnState.setTraffic(Traffic(available = false)); return@launch }
            var lastRx = rx0; var lastTx = tx0
            VpnState.setTraffic(Traffic())
            while (isActive) {
                delay(1000)
                val rx = TrafficStats.getUidRxBytes(uid); val tx = TrafficStats.getUidTxBytes(uid)
                VpnState.setTraffic(Traffic(down = (rx - rx0).coerceAtLeast(0), up = (tx - tx0).coerceAtLeast(0), downSpeed = (rx - lastRx).coerceAtLeast(0), upSpeed = (tx - lastTx).coerceAtLeast(0)))
                lastRx = rx; lastTx = tx
            }
        }
    }

    private fun stopTunnel(keepError: Boolean = false) {
        statsJob?.cancel(); statsJob = null
        if (!keepError) VpnState.log("Disconnected")
        runCatching { core?.stop() }
        core = null
        if (!keepError) VpnState.set(VpnStatus(Phase.Off))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() { stopTunnel() }   // the user turned the VPN off from system settings
    override fun onDestroy() { runCatching { core?.stop() }; scope.cancel(); super.onDestroy() }

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification).setContentTitle(getString(R.string.app_name)).setContentText(getString(R.string.notif_text))
            .setContentIntent(open).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
    }

    companion object {
        const val ACTION_START = "app.amnezia.client.START"
        const val ACTION_STOP = "app.amnezia.client.STOP"
        const val EXTRA_SERVER_ID = "server_id"
        private const val CHANNEL = "vpn"
    }
}
