package app.amnezia.client.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/** Real TCP connect time in ms, or null when the port is unreachable or times out. UDP-only servers (hysteria2, wireguard) have no TCP port to probe. */
suspend fun tcpPing(host: String, port: Int, timeoutMs: Int = 3000): Int? = withContext(Dispatchers.IO) {
    try {
        Socket().use { s ->
            val start = System.nanoTime()
            s.connect(InetSocketAddress(host, port), timeoutMs)
            maxOf(1, ((System.nanoTime() - start) / 1_000_000).toInt())
        }
    } catch (_: Exception) { null }
}

fun isUdpOnly(protocol: String) = protocol == "hysteria2" || protocol == "wireguard"

/** Pings every server (at most 8 at a time). The result maps server id to ms; null = no answer; UDP-only servers are skipped. */
suspend fun pingAll(servers: List<Server>, onResult: (String, Int?) -> Unit) = coroutineScope {
    val gate = Semaphore(8)
    servers.filterNot { isUdpOnly(it.protocol) }.map { s -> async { gate.withPermit { onResult(s.id, tcpPing(s.host, s.port)) } } }.awaitAll()
}
