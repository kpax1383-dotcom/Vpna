package app.amnezia.client

import app.amnezia.client.data.DeviceInfo
import app.amnezia.client.data.Http
import app.amnezia.client.data.HttpResult
import app.amnezia.client.data.SubSettings
import app.amnezia.client.data.SubscriptionException
import app.amnezia.client.data.asciiHeader
import app.amnezia.client.data.fetchSubscription
import app.amnezia.client.data.normalizeSubscriptionUrl
import app.amnezia.client.data.parseUserInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.Base64

class SubscriptionTest {
    private val vless = "vless://11111111-1111-1111-1111-111111111111@1.2.3.4:443?security=tls#A"
    private val dev = DeviceInfo("Android", "14", "Pixel 8", "ru")
    private val settings = SubSettings(userAgent = "sing-box", sendHwid = false, hwid = "abc123", device = dev)

    @Test fun deepLinksAreUnwrapped() {
        assertEquals("https://x.com/s", normalizeSubscriptionUrl("happ://add/https://x.com/s"))
        assertEquals("https://x.com/s?a=1", normalizeSubscriptionUrl("amnezia://add/https%3A%2F%2Fx.com%2Fs%3Fa%3D1"))
        try { normalizeSubscriptionUrl("happ://crypt4/abc"); fail() } catch (e: SubscriptionException) { assertEquals("encrypted", e.code) }
        try { normalizeSubscriptionUrl("ftp://x"); fail() } catch (e: SubscriptionException) { assertEquals("bad_url", e.code) }
    }

    @Test fun userInfoAndAsciiHeader() {
        val u = parseUserInfo("upload=1; download=2; total=10; expire=99")
        assertNotNull(u); assertEquals(10L, u!!.total); assertEquals(99L, u.expire)
        assertEquals("Pixel 8", asciiHeader("Pixel 8", "Android")); assertEquals("Android", asciiHeader("Мой телефон", "Android"))
    }

    @Test fun deviceLimitShowsProviderMessageAndHwid() {
        val http = Http { _, _ -> HttpResult(403, mapOf("x-hwid-max-devices-reached" to "true", "announce" to "base64:" + Base64.getEncoder().encodeToString("Max 2 devices".toByteArray())), "") }
        try { fetchSubscription("https://x.com/s", settings, http); fail() } catch (e: SubscriptionException) {
            assertTrue(e.message!!.contains("Device limit reached")); assertTrue(e.message!!.contains("Max 2 devices")); assertTrue(e.message!!.contains("abc123"))
        }
    }

    @Test fun missingHwid404IsRetriedWithStableHwidAndDeviceHeaders() {
        val calls = ArrayList<Map<String, String>>()
        val http = Http { _, h ->
            calls.add(h)
            if (h.containsKey("x-hwid")) HttpResult(200, mapOf("profile-title" to "base64:" + Base64.getEncoder().encodeToString("Prov".toByteArray())), vless)
            else HttpResult(404, mapOf("x-hwid-not-supported" to "true"), "")
        }
        val r = fetchSubscription("https://x.com/s", settings, http)
        assertEquals(1, r.servers.size); assertEquals("Prov", r.meta.title)
        assertEquals("abc123", calls[1]["x-hwid"]); assertEquals("Android", calls[1]["x-device-os"]); assertEquals("Pixel 8", calls[1]["x-device-model"])
        assertTrue(calls[1]["User-Agent"]!!.startsWith("Happ/"))
    }

    @Test fun happAndHwidSettingsSendHeadersOnTheFirstRequest() {
        val calls = ArrayList<Map<String, String>>()
        val http = Http { _, h -> calls.add(h); HttpResult(200, emptyMap(), vless) }
        fetchSubscription("https://x.com/s", settings.copy(userAgent = "Happ", sendHwid = true), http)
        assertEquals(1, calls.size); assertEquals("abc123", calls[0]["x-hwid"]); assertEquals("ru", calls[0]["x-device-locale"])
    }

    @Test fun emptyBodyIsAnError() {
        val http = Http { _, _ -> HttpResult(200, emptyMap(), "nothing useful here") }
        try { fetchSubscription("https://x.com/s", settings, http); fail() } catch (e: SubscriptionException) { assertEquals("empty", e.code) }
    }
}
