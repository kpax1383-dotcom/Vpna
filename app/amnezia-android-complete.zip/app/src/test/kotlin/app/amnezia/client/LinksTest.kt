package app.amnezia.client

import app.amnezia.client.config.ConfigError
import app.amnezia.client.config.parseHysteria2
import app.amnezia.client.config.parseLink
import app.amnezia.client.config.parseShadowsocks
import app.amnezia.client.config.parseText
import app.amnezia.client.config.parseVless
import app.amnezia.client.config.parseVmess
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.Base64

class LinksTest {
    private val uuid = "11111111-1111-1111-1111-111111111111"
    private fun b64(s: String) = Base64.getEncoder().encodeToString(s.toByteArray())

    @Test fun vlessReality() {
        val s = parseVless("vless://$uuid@1.2.3.4:443?security=reality&sni=a.com&fp=chrome&pbk=PUB&sid=ab&type=tcp&flow=xtls-rprx-vision#My%20Server")
        assertEquals("My Server", s.name)
        assertEquals("TCP Reality", s.transport)
        assertEquals(uuid, s.outbound.getString("uuid"))
        assertEquals("xtls-rprx-vision", s.outbound.getString("flow"))
        val tls = s.outbound.getJSONObject("tls")
        assertEquals("PUB", tls.getJSONObject("reality").getString("public_key"))
        assertEquals("chrome", tls.getJSONObject("utls").getString("fingerprint"))
        assertEquals("a.com", tls.getString("server_name"))
    }

    @Test fun vlessWebSocketAndCyrillicName() {
        val s = parseVless("vless://$uuid@host.example:8443?security=tls&type=ws&path=%2Fws&host=h.example#%D0%A8%D0%B2%D0%B5%D1%86%D0%B8%D1%8F")
        assertEquals("Швеция", s.name)
        val tr = s.outbound.getJSONObject("transport")
        assertEquals("ws", tr.getString("type")); assertEquals("/ws", tr.getString("path"))
        assertEquals("h.example", tr.getJSONObject("headers").getString("Host"))
    }

    @Test fun vlessIpv6AndDefaultPort() {
        val s = parseVless("vless://$uuid@[2001:db8::1]?security=tls#v6")
        assertEquals("2001:db8::1", s.host); assertEquals(443, s.port)
    }

    @Test fun vmess() {
        val json = """{"v":"2","ps":"VM","add":"vm.example","port":"443","id":"$uuid","aid":"0","net":"ws","host":"h.example","path":"/p","tls":"tls"}"""
        val s = parseVmess("vmess://" + b64(json))
        assertEquals("VM", s.name); assertEquals("WS TLS", s.transport); assertEquals(443, s.port)
        assertEquals("auto", s.outbound.getString("security"))
    }

    @Test fun shadowsocksSip002() {
        val s = parseShadowsocks("ss://" + b64("aes-256-gcm:secret") + "@1.2.3.4:8388#SS")
        assertEquals("aes-256-gcm", s.outbound.getString("method")); assertEquals("secret", s.outbound.getString("password")); assertEquals(8388, s.port)
    }

    @Test fun hysteria2() {
        val s = parseHysteria2("hy2://pass@h.example:443?sni=s.example&insecure=1&obfs=salamander&obfs-password=op#H")
        assertEquals("hysteria2", s.outbound.getString("type")); assertEquals("pass", s.outbound.getString("password"))
        assertEquals("op", s.outbound.getJSONObject("obfs").getString("password"))
        assertTrue(s.outbound.getJSONObject("tls").getBoolean("insecure"))
    }

    @Test fun unsupportedTransportAndLink() {
        try { parseVless("vless://$uuid@h:443?type=xhttp"); fail() } catch (e: ConfigError) { assertEquals("unsupported", e.code) }
        try { parseLink("foo://bar"); fail() } catch (e: ConfigError) { assertEquals("unsupported", e.code) }
    }

    @Test fun textWithBase64List() {
        val list = "vless://$uuid@1.1.1.1:443?security=tls#A\nvless://$uuid@2.2.2.2:443?security=tls#B\n"
        val r = parseText(b64(list))
        assertEquals(2, r.servers.size); assertEquals(listOf("A", "B"), r.servers.map { it.name })
    }

    @Test fun textReportsBadLinesAndEmpty() {
        assertEquals(1, parseText("vless://$uuid@1.1.1.1:443?security=tls#A\nfoo://x").servers.size)
        assertTrue(parseText("   ").errors.isNotEmpty())
    }

    @Test fun singBoxJson() {
        val r = parseText("""{"outbounds":[{"type":"direct","tag":"d"},{"type":"trojan","tag":"T","server":"t.example","server_port":443,"password":"p"}]}""")
        assertEquals(1, r.servers.size); assertEquals("T", r.servers[0].name)
        assertTrue(!r.servers[0].outbound.has("tag"))
    }
}
