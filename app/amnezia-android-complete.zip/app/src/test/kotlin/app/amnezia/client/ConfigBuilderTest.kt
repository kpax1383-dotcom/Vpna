package app.amnezia.client

import app.amnezia.client.config.ConfigBuilder
import app.amnezia.client.config.CoreSettings
import app.amnezia.client.config.parseHysteria2
import app.amnezia.client.config.parseVless
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfigBuilderTest {
    private val uuid = "11111111-1111-1111-1111-111111111111"

    @Test fun tunConfigShape() {
        val cfg = JSONObject(ConfigBuilder.build(parseVless("vless://$uuid@1.2.3.4:443?security=tls#A"), CoreSettings()))
        val tun = cfg.getJSONArray("inbounds").getJSONObject(0)
        assertEquals("tun", tun.getString("type")); assertTrue(tun.getBoolean("auto_route"))
        assertEquals("proxy", cfg.getJSONObject("route").getString("final"))
        assertEquals("proxy", cfg.getJSONArray("outbounds").getJSONObject(0).getString("tag"))
        assertEquals("remote", cfg.getJSONObject("dns").getString("final"))
        val rules = cfg.getJSONObject("route").getJSONArray("rules")
        assertEquals("sniff", rules.getJSONObject(0).getString("action"))
    }

    @Test fun sniffingOffHijacksPort53() {
        val cfg = JSONObject(ConfigBuilder.build(parseVless("vless://$uuid@1.2.3.4:443?security=tls#A"), CoreSettings(sniffing = false)))
        assertEquals(53, cfg.getJSONObject("route").getJSONArray("rules").getJSONObject(0).getInt("port"))
    }

    @Test fun dnsFormats() {
        assertEquals("https", ConfigBuilder.dnsServer("https://dns.google/dns-query", "r", "proxy").getString("type"))
        assertEquals("/dns-query", ConfigBuilder.dnsServer("https://1.1.1.1", "r").getString("path"))
        assertEquals("tls", ConfigBuilder.dnsServer("tls://dns.google", "r").getString("type"))
        val u = ConfigBuilder.dnsServer("udp://8.8.8.8", "r"); assertEquals("udp", u.getString("type")); assertEquals("8.8.8.8", u.getString("server"))
        assertEquals("1.1.1.1", ConfigBuilder.dnsServer("  ", "r").getString("server"))
    }

    @Test fun evasionAppliesToTlsButNotQuic() {
        val s = CoreSettings(tlsFragment = true, fingerprint = "firefox", mux = true)
        val v = JSONObject(ConfigBuilder.build(parseVless("vless://$uuid@1.2.3.4:443?security=tls#A"), s)).getJSONArray("outbounds").getJSONObject(0)
        assertTrue(v.getJSONObject("tls").getBoolean("fragment"))
        assertEquals("firefox", v.getJSONObject("tls").getJSONObject("utls").getString("fingerprint"))
        assertTrue(v.getJSONObject("multiplex").getBoolean("enabled"))
        val h = JSONObject(ConfigBuilder.build(parseHysteria2("hy2://p@h.example:443#H"), s)).getJSONArray("outbounds").getJSONObject(0)
        assertFalse(h.getJSONObject("tls").has("fragment")); assertFalse(h.has("multiplex"))
    }

    @Test fun visionFlowIsNeverMultiplexed() {
        val v = JSONObject(ConfigBuilder.build(parseVless("vless://$uuid@1.2.3.4:443?security=reality&pbk=P&flow=xtls-rprx-vision#A"), CoreSettings(mux = true))).getJSONArray("outbounds").getJSONObject(0)
        assertFalse(v.has("multiplex"))
    }
}
