package app.amnezia.client

import app.amnezia.client.config.isWireGuardConf
import app.amnezia.client.config.parseText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FormatsTest {
    private val uuid = "11111111-1111-1111-1111-111111111111"

    @Test fun wireGuardConf() {
        val conf = """
            [Interface]
            PrivateKey = PRIV
            Address = 10.0.0.2/32, fd00::2/128
            MTU = 1280

            [Peer]
            PublicKey = PUB
            Endpoint = 1.2.3.4:51820
            AllowedIPs = 0.0.0.0/0, ::/0
            PersistentKeepalive = 25
        """.trimIndent()
        assertTrue(isWireGuardConf(conf))
        val r = parseText(conf, "home.conf")
        assertEquals(1, r.servers.size)
        val s = r.servers[0]
        assertEquals("home", s.name); assertEquals("endpoint", s.kind); assertEquals(51820, s.port)
        assertEquals(1280, s.outbound.getInt("mtu"))
        val peer = s.outbound.getJSONArray("peers").getJSONObject(0)
        assertEquals("PUB", peer.getString("public_key")); assertEquals(25, peer.getInt("persistent_keepalive_interval"))
    }

    @Test fun clashYaml() {
        val yaml = """
            mixed-port: 7890
            proxies:
              - name: "VL"
                type: vless
                server: a.example
                port: 443
                uuid: $uuid
                tls: true
                servername: s.example
                network: ws
                ws-opts:
                  path: /ws
                  headers:
                    Host: h.example
              - name: "SS"
                type: ss
                server: b.example
                port: 8388
                cipher: aes-256-gcm
                password: secret
              - name: "BAD"
                type: ssr
                server: c.example
                port: 1
        """.trimIndent()
        val r = parseText(yaml)
        assertEquals(listOf("VL", "SS"), r.servers.map { it.name })
        assertEquals("WS TLS", r.servers[0].transport)
        assertEquals("/ws", r.servers[0].outbound.getJSONObject("transport").getString("path"))
        assertEquals("h.example", r.servers[0].outbound.getJSONObject("transport").getJSONObject("headers").getString("Host"))
        assertEquals("aes-256-gcm", r.servers[1].outbound.getString("method"))
        assertEquals(1, r.errors.size); assertTrue(r.errors[0].contains("not supported"))
    }

    @Test fun xrayJsonArrayOfConfigs() {
        val json = """[{"remarks":"R","outbounds":[
            {"protocol":"vless","tag":"proxy","settings":{"vnext":[{"address":"x.example","port":443,"users":[{"id":"$uuid","flow":"xtls-rprx-vision"}]}]},
             "streamSettings":{"network":"tcp","security":"reality","realitySettings":{"serverName":"s.com","publicKey":"PUB","shortId":"ab","fingerprint":"chrome"}}},
            {"protocol":"freedom","tag":"direct"}]}]"""
        val r = parseText(json)
        assertEquals(1, r.servers.size)
        val s = r.servers[0]
        assertEquals("R", s.name); assertEquals("TCP Reality", s.transport)
        assertEquals("xtls-rprx-vision", s.outbound.getString("flow"))
        assertEquals("PUB", s.outbound.getJSONObject("tls").getJSONObject("reality").getString("public_key"))
    }

    @Test fun xrayUnsupportedTransportIsReportedNotThrown() {
        val json = """{"outbounds":[{"protocol":"vless","settings":{"vnext":[{"address":"x.example","port":443,"users":[{"id":"$uuid"}]}]},"streamSettings":{"network":"xhttp"}}]}"""
        val r = parseText(json)
        assertTrue(r.servers.isEmpty()); assertTrue(r.errors[0].contains("XHTTP"))
    }

    @Test fun openVpnProfilesAreRejectedWithAClearMessage() {
        val r = parseText("client\ndev tun\nremote vpn.example 1194\n")
        assertTrue(r.servers.isEmpty()); assertTrue(r.errors[0].contains("OpenVPN"))
    }

    @Test fun singBoxJsonStillWorks() {
        val r = parseText("""{"outbounds":[{"type":"trojan","tag":"T","server":"t.example","server_port":443,"password":"p"}]}""")
        assertEquals(1, r.servers.size)
    }
}
